// Bokeà - Frontend Application

const API_BASE = '/api';
const parseTaskId = id => isNaN(Number(id)) ? id : Number(id);

// localStorage keys
const STORAGE_KEYS = {
    TASKS: 'lifeSorted_tasks',
    HISTORY: 'lifeSorted_history'
};

// Global State
let tasks = [];
let digest = { redCount: 0, amberCount: 0, tasks: [] };
let historyData = [];
let activeFilter = 'all';
let chartRange = 7; // Days to show in graph
let isFallbackMode = false; // Flag for localStorage fallback

// Lucide Icons initialization helper
function refreshIcons() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// 1. LocalStorage Mock Database Initialization
function initLocalStorage() {
    if (!localStorage.getItem(STORAGE_KEYS.TASKS)) {
        const now = new Date();
        const defaultTasks = [
            {
                id: 'task_1',
                name: 'Daily Hydration & Morning Walk',
                category: 'Health & Vitality',
                description: 'Drink 500ml of water and complete a brisk 15-minute walk outside.',
                type: 'interval',
                intervalDays: 1,
                createdAt: new Date(now.getTime() - 10 * 86400000).toISOString(),
                lastCompleted: new Date(now.getTime() - 1 * 86400000).toISOString(), // Done yesterday -> Green
                snoozeUntil: null
            },
            {
                id: 'task_2',
                name: 'Strength Training Routine',
                category: 'Health & Vitality',
                description: 'Full body resistance training at the local gym.',
                type: 'interval',
                intervalDays: 3,
                createdAt: new Date(now.getTime() - 10 * 86400000).toISOString(),
                lastCompleted: new Date(now.getTime() - 6 * 86400000).toISOString(), // Red (overdue)
                snoozeUntil: null
            },
            {
                id: 'task_3',
                name: 'Review Monthly Budget & Spending',
                category: 'Career & Finance',
                description: 'Reconcile transactions, allocate savings, and update sheet.',
                type: 'interval',
                intervalDays: 7,
                createdAt: new Date(now.getTime() - 20 * 86400000).toISOString(),
                lastCompleted: new Date(now.getTime() - 9 * 86400000).toISOString(), // Amber (overdue)
                snoozeUntil: null
            },
            {
                id: 'task_4',
                name: 'Submit Monthly Freelance Invoices',
                category: 'Career & Finance',
                description: 'Email hours and invoice spreadsheet to clients.',
                type: 'fixed',
                dueDate: new Date(now.getTime() + 2 * 86400000).toISOString().split('T')[0], // Amber (due in 2 days)
                createdAt: new Date(now.getTime() - 5 * 86400000).toISOString(),
                lastCompleted: null,
                snoozeUntil: null
            },
            {
                id: 'task_5',
                name: 'Weekly Call with Family',
                category: 'Relationships & Social',
                description: 'Call parents and siblings for a catching-up chat.',
                type: 'interval',
                intervalDays: 7,
                createdAt: new Date(now.getTime() - 30 * 86400000).toISOString(),
                lastCompleted: new Date().toISOString(), // Done today -> Green
                snoozeUntil: null
            },
            {
                id: 'task_6',
                name: 'Organize Board Game Night',
                category: 'Relationships & Social',
                description: 'Send group poll for availability and book venue.',
                type: 'fixed',
                dueDate: new Date(now.getTime() - 1 * 86400000).toISOString().split('T')[0], // Red (due yesterday)
                createdAt: new Date(now.getTime() - 5 * 86400000).toISOString(),
                lastCompleted: null,
                snoozeUntil: null
            },
            {
                id: 'task_7',
                name: '10-Minute Breath Mindfulness',
                category: 'Mind & Environment',
                description: 'Sit in silence, focus on deep nasal breathing.',
                type: 'interval',
                intervalDays: 1,
                createdAt: new Date(now.getTime() - 15 * 86400000).toISOString(),
                lastCompleted: new Date(now.getTime() - 1.2 * 86400000).toISOString(), // Amber (due today)
                snoozeUntil: null
            },
            {
                id: 'task_8',
                name: 'Tidy & Vacuum Workspace',
                category: 'Mind & Environment',
                description: 'Clean keyboard, wipe monitor, file stray sheets.',
                type: 'interval',
                intervalDays: 14,
                createdAt: new Date(now.getTime() - 20 * 86400000).toISOString(),
                lastCompleted: new Date(now.getTime() - 4 * 86400000).toISOString(), // Green
                snoozeUntil: null
            }
        ];
        localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(defaultTasks));
    }

    if (!localStorage.getItem(STORAGE_KEYS.HISTORY)) {
        const mockHistory = [];
        const now = new Date();
        for (let i = 29; i >= 0; i--) {
            const date = new Date(now.getTime() - i * 86400000);
            const dateStr = date.toISOString().split('T')[0];
            
            let total = Math.floor(Math.random() * 4) + 4; // 4 to 7
            let completed = Math.floor(Math.random() * (total - 1)) + 1; // 1 to total
            
            const rate = Math.round((completed / total) * 100);
            
            mockHistory.push({
                date: dateStr,
                completed: completed,
                total: total,
                rate: rate
            });
        }
        localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(mockHistory));
    }
}

// 2. Dynamic Task State Calculation (Fallback logic / Client-side validator)
function calculateTaskState(task) {
    const now = new Date();
    
    // Check if task has a future snooze date
    if (task.snoozeUntil) {
        const snoozeDate = new Date(task.snoozeUntil);
        if (snoozeDate > now) {
            return 'Green'; // Snoozed tasks are temporarily safe
        }
    }
    
    // Check if task is already completed today
    if (task.lastCompleted) {
        const lastComp = new Date(task.lastCompleted);
        const todayStr = now.toISOString().split('T')[0];
        const lastCompStr = lastComp.toISOString().split('T')[0];
        if (lastCompStr === todayStr) {
            return 'Green'; // Completed today
        }
    }

    if (task.type === 'fixed') {
        if (!task.dueDate) return 'Green';
        const due = new Date(task.dueDate + 'T23:59:59'); // set to end of day local
        const diffMs = due - now;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) {
            return 'Red';
        } else if (diffDays <= 2) {
            return 'Amber';
        } else {
            return 'Green';
        }
    } else {
        // Interval-based
        const interval = parseInt(task.intervalDays) || 1;
        const baseDate = task.lastCompleted ? new Date(task.lastCompleted) : new Date(task.createdAt);
        
        const diffMs = now - baseDate;
        const diffDays = diffMs / (1000 * 60 * 60 * 24);
        
        if (diffDays >= interval * 1.5) {
            return 'Red';
        } else if (diffDays >= interval) {
            return 'Amber';
        } else {
            return 'Green';
        }
    }
}

function mapBackendTask(task) {
    if (!task) return task;
    if (task.title && !task.name) {
        task.name = task.title;
    }
    if (task.dueDate && typeof task.dueDate === 'object' && task.dueDate.value) {
        task.dueDate = task.dueDate.value.split('T')[0];
    }
    if (task.sector && !task.category) {
        if (task.sector === 'HealthAndVitality') task.category = 'Health & Vitality';
        else if (task.sector === 'CareerAndFinance') task.category = 'Career & Finance';
        else if (task.sector === 'RelationshipsAndSocial') task.category = 'Relationships & Social';
        else if (task.sector === 'MindAndEnvironment') task.category = 'Mind & Environment';
        else task.category = task.sector;
    }
    return task;
}

// 3. API Request Wrapper with Auto-Fallback to LocalStorage
async function apiRequest(endpoint, method = 'GET', body = null) {
    const url = `${API_BASE}${endpoint}`;
    
    let requestBody = body;
    if (body && (endpoint === '/tasks' || (endpoint.startsWith('/tasks') && !endpoint.endsWith('/complete') && !endpoint.endsWith('/snooze')))) {
        // Outbound mapping for C# backend
        requestBody = {
            title: body.name,
            description: body.description,
            sector: body.category === 'Health & Vitality' ? 'HealthAndVitality' :
                    body.category === 'Career & Finance' ? 'CareerAndFinance' :
                    body.category === 'Relationships & Social' ? 'RelationshipsAndSocial' :
                    body.category === 'Mind & Environment' ? 'MindAndEnvironment' : body.category,
            intervalType: body.type === 'interval' ? 'IntervalBased' : 'FixedDate',
            intervalDays: body.intervalDays,
            dueDate: body.dueDate
        };
    }

    const options = {
        method,
        headers: {
            'Content-Type': 'application/json'
        }
    };
    
    const token = localStorage.getItem('bokea_auth_token');
    if (token) {
        options.headers['Authorization'] = `Bearer ${token}`;
    }
    if (requestBody) {
        options.body = JSON.stringify(requestBody);
    }
    
    if (isFallbackMode) {
        return handleLocalStorageFallback(endpoint, method, body);
    }
    
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            if (response.status === 401) {
                logoutUser();
                throw new Error("Unauthorized");
            }
            throw new Error(`API returned ${response.status}`);
        }
        if (response.status === 204) {
            return null;
        }
        let data = await response.json();
        if (data) {
            if (Array.isArray(data)) {
                data = data.map(mapBackendTask);
            } else if (data.id || data.title) {
                data = mapBackendTask(data);
            }
        }
        return data;
    } catch (error) {
        console.warn(`API call failed for ${method} ${endpoint}. Activating localStorage fallback.`, error);
        isFallbackMode = true;
        showToast("Connected in offline storage mode.", "warning");
        return handleLocalStorageFallback(endpoint, method, body);
    }
}

// LocalStorage mock router matching the API endpoints
function handleLocalStorageFallback(endpoint, method, body) {
    initLocalStorage();
    
    const localTasks = JSON.parse(localStorage.getItem(STORAGE_KEYS.TASKS));
    const localHistory = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY));
    
    // GET /tasks
    if (endpoint === '/tasks' && method === 'GET') {
        return localTasks;
    }
    
    // GET /digest
    if (endpoint === '/digest' && method === 'GET') {
        const warnings = localTasks.filter(t => {
            const state = calculateTaskState(t);
            return state === 'Red' || state === 'Amber';
        }).map(t => ({
            id: t.id,
            name: t.name,
            category: t.category,
            state: calculateTaskState(t),
            description: t.description,
            type: t.type,
            dueDate: t.dueDate,
            intervalDays: t.intervalDays
        }));
        
        return {
            redCount: warnings.filter(w => w.state === 'Red').length,
            amberCount: warnings.filter(w => w.state === 'Amber').length,
            tasks: warnings
        };
    }
    
    // POST /tasks/:id/complete
    let match = endpoint.match(/^\/tasks\/(.+)\/complete$/);
    if (match && method === 'POST') {
        const taskId = match[1];
        const idx = localTasks.findIndex(t => t.id === taskId);
        if (idx !== -1) {
            localTasks[idx].lastCompleted = new Date().toISOString();
            localTasks[idx].snoozeUntil = null;
            localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(localTasks));
            
            updateLocalHistory();
            return { success: true, task: localTasks[idx] };
        }
        throw new Error("Task not found");
    }
    
    // POST /tasks/:id/snooze
    match = endpoint.match(/^\/tasks\/(.+)\/snooze$/);
    if (match && method === 'POST') {
        const taskId = match[1];
        const idx = localTasks.findIndex(t => t.id === taskId);
        if (idx !== -1) {
            const durationHours = (body && body.durationHours) || parseInt(localStorage.getItem('bokea_default_snooze')) || 24;
            const snoozeDate = new Date();
            snoozeDate.setHours(snoozeDate.getHours() + durationHours);
            localTasks[idx].snoozeUntil = snoozeDate.toISOString();
            localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(localTasks));
            
            return { success: true, task: localTasks[idx] };
        }
        throw new Error("Task not found");
    }
    
    // POST /tasks
    if (endpoint === '/tasks' && method === 'POST') {
        const newTask = {
            id: 'task_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            name: body.name,
            category: body.category,
            description: body.description || '',
            type: body.type,
            intervalDays: body.type === 'interval' ? parseInt(body.intervalDays) || 1 : null,
            dueDate: body.type === 'fixed' ? body.dueDate : null,
            createdAt: new Date().toISOString(),
            lastCompleted: null,
            snoozeUntil: null
        };
        localTasks.push(newTask);
        localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(localTasks));
        
        updateLocalHistory();
        return newTask;
    }
    
    // PUT /tasks/:id
    match = endpoint.match(/^\/tasks\/(.+)$/);
    if (match && method === 'PUT') {
        const taskId = match[1];
        const idx = localTasks.findIndex(t => t.id === taskId);
        if (idx !== -1) {
            localTasks[idx].name = body.name;
            localTasks[idx].category = body.category;
            localTasks[idx].description = body.description || '';
            localTasks[idx].type = body.type;
            localTasks[idx].intervalDays = body.type === 'interval' ? parseInt(body.intervalDays) || 1 : null;
            localTasks[idx].dueDate = body.type === 'fixed' ? body.dueDate : null;
            
            localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(localTasks));
            updateLocalHistory();
            return localTasks[idx];
        }
        throw new Error("Task not found");
    }
    
    // DELETE /tasks/:id
    match = endpoint.match(/^\/tasks\/(.+)$/);
    if (match && method === 'DELETE') {
        const taskId = match[1];
        const filtered = localTasks.filter(t => t.id !== taskId);
        localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(filtered));
        
        updateLocalHistory();
        return { success: true };
    }
    
    // GET /history or /tasks/history
    if ((endpoint === '/history' || endpoint === '/tasks/history') && method === 'GET') {
        return localHistory;
    }
    
    // POST /auth/setup fallback
    if (endpoint === '/auth/setup' && method === 'POST') {
        return { success: true };
    }
    
    throw new Error(`Unsupported fallback endpoint: ${method} ${endpoint}`);
}

// Update the dynamic history metrics in local storage
function updateLocalHistory() {
    initLocalStorage();
    const localTasks = JSON.parse(localStorage.getItem(STORAGE_KEYS.TASKS)) || [];
    const localHistory = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY)) || [];
    
    const todayStr = new Date().toISOString().split('T')[0];
    
    const completedToday = localTasks.filter(t => {
        if (!t.lastCompleted) return false;
        return t.lastCompleted.split('T')[0] === todayStr;
    }).length;
    
    const amberRedCount = localTasks.filter(t => {
        const state = calculateTaskState(t);
        return state === 'Red' || state === 'Amber';
    }).length;
    
    const totalDue = completedToday + amberRedCount;
    
    let todayLogIdx = localHistory.findIndex(h => h.date === todayStr);
    const newLog = {
        date: todayStr,
        completed: completedToday,
        total: totalDue || 1,
        rate: Math.round((completedToday / (totalDue || 1)) * 100)
    };
    
    if (todayLogIdx !== -1) {
        localHistory[todayLogIdx] = newLog;
    } else {
        localHistory.push(newLog);
    }
    
    if (localHistory.length > 30) {
        localHistory.shift();
    }
    
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(localHistory));
}

// 4. Data Loading and Screen Rendering Functions

function renderNotifications() {
    const listContainer = document.getElementById('notificationList');
    const badge = document.getElementById('notificationBadge');
    if (!listContainer || !badge) return;

    // Filter tasks that are Red or Amber
    const warningTasks = tasks.filter(t => {
        const state = t.state || calculateTaskState(t);
        return state === 'Red' || state === 'Amber';
    });

    const count = warningTasks.length;
    if (count > 0) {
        badge.textContent = count;
        badge.classList.remove('hidden');
        listContainer.innerHTML = '';
        warningTasks.forEach(task => {
            const state = task.state || calculateTaskState(task);
            const stateLower = state.toLowerCase();
            const noteItem = document.createElement('a');
            noteItem.href = '#';
            noteItem.className = 'notification-item';
            noteItem.innerHTML = `
                <span class="dot dot-${stateLower}" style="margin-top: 4px; flex-shrink: 0;"></span>
                <div class="notification-item-text">
                    <span class="notification-item-title" style="font-weight: 600;">${task.name}</span>
                    <span class="notification-item-desc">Overdue: Action required (${state} status)</span>
                </div>
            `;
            noteItem.addEventListener('click', (e) => {
                e.preventDefault();
                document.getElementById('notificationMenuBox').classList.remove('show');
                openEditTaskModal(task.id);
            });
            listContainer.appendChild(noteItem);
        });
    } else {
        badge.classList.add('hidden');
        listContainer.innerHTML = `<div class="notification-empty">No notifications</div>`;
    }
}

async function loadDashboardData() {
    try {
        // Fetch tasks, digest, and history in parallel to eliminate sequential waterfall
        const [tasksData, digestData, historyLogs] = await Promise.all([
            apiRequest('/tasks', 'GET'),
            apiRequest('/digest', 'GET'),
            apiRequest('/history', 'GET').catch(() => apiRequest('/tasks/history', 'GET'))
        ]);

        tasks = tasksData || [];
        digest = digestData || { redCount: 0, amberCount: 0, tasks: [] };
        historyData = historyLogs || [];
        
        // Calculate states client-side if the API tasks list items don't have a state field
        const durations = JSON.parse(localStorage.getItem('bokea_task_durations') || '{}');
        tasks.forEach(t => {
            if (durations[t.id]) {
                t.durationMinutes = durations[t.id];
            }
            if (!t.state) {
                t.state = calculateTaskState(t);
            }
        });
        
        // Render panels
        renderStats();
        renderMorningDigest();
        renderNotifications();
        renderTaskGrid();
        renderTodayProgress();
        renderHomeCalendar();
        renderNextUpTask();
        renderDailyScheduleTimeline();
        renderTasksViewNextTasks();
        
    } catch (err) {
        console.error("Critical error loading dashboard data.", err);
    }
}

// Stats panel rendering
function renderStats() {
    const todayStr = new Date().toISOString().split('T')[0];
    
    // 1. Done Today
    const completedCount = tasks.filter(t => {
        if (!t.lastCompleted) return false;
        const compDateStr = new Date(t.lastCompleted).toISOString().split('T')[0];
        return compDateStr === todayStr;
    }).length;
    document.getElementById('statsCompletedToday').textContent = completedCount;
    
    // 2. Current Streak
    let streak = 0;
    if (historyData && historyData.length > 0) {
        const sorted = [...historyData].sort((a, b) => new Date(b.date) - new Date(a.date));
        
        let checkDate = new Date();
        const todayLog = sorted.find(h => h.date === todayStr);
        if (!todayLog || todayLog.completed === 0) {
            // If nothing done today, start checking from yesterday
            checkDate.setDate(checkDate.getDate() - 1);
        }
        
        while (true) {
            const dateStr = checkDate.toISOString().split('T')[0];
            const log = sorted.find(h => h.date === dateStr);
            if (log && log.completed > 0) {
                streak++;
                checkDate.setDate(checkDate.getDate() - 1);
            } else {
                break;
            }
        }
    }
    document.getElementById('statsStreak').textContent = `${streak}d`;
    
    // 3. Compliance Rate (average compliance of the visible graph range)
    let avgComp = 0;
    if (historyData && historyData.length > 0) {
        const sorted = [...historyData].sort((a, b) => new Date(b.date) - new Date(a.date));
        const slice = sorted.slice(0, chartRange);
        const sum = slice.reduce((acc, h) => acc + h.rate, 0);
        avgComp = Math.round(sum / (slice.length || 1));
    }
    document.getElementById('statsRate').textContent = `${avgComp}%`;
}

// Today's Clock-style Progress Ring Rendering
// Today's Clock-style Progress Ring Rendering
function renderTodayProgress() {
    const todayStr = new Date().toISOString().split('T')[0];
    
    // 1. Calculate Completed Today
    const completedCount = tasks.filter(t => {
        if (!t.lastCompleted) return false;
        const compDateStr = new Date(t.lastCompleted).toISOString().split('T')[0];
        return compDateStr === todayStr;
    }).length;
    
    // 2. Calculate Warning Tasks (Amber & Red) due today
    const warningCount = tasks.filter(t => {
        const state = t.state || calculateTaskState(t);
        return state === 'Red' || state === 'Amber';
    }).length;
    
    const totalDueToday = completedCount + warningCount;
    const badge = document.getElementById('progressBadge');
    const body = document.getElementById('todayProgressBody');

    if (totalDueToday === 0) {
        if (badge) badge.classList.add('hidden');
        if (body) {
            body.innerHTML = `
                <div class="empty-progress-state" style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 15px; padding: 30px 10px; text-align: center; width: 100%;">
                    <i data-lucide="coffee" style="width: 48px; height: 48px; color: var(--color-green); stroke-width: 1.2;"></i>
                    <p style="font-family: var(--font-inter); font-size: 0.9rem; color: var(--text-secondary); line-height: 1.5; margin: 0; max-width: 180px;">Nothing scheduled — enjoy the evening.</p>
                </div>
            `;
            refreshIcons();
        }
        return;
    }

    if (badge) {
        badge.classList.remove('hidden');
    }
    
    if (body && !body.querySelector('.circular-progress-wrapper')) {
        body.innerHTML = `
            <div class="circular-progress-wrapper" style="width: 200px; height: 200px;">
                <svg class="progress-ring-svg" width="200" height="200">
                    <circle class="progress-ring-bg" cx="100" cy="100" r="84" stroke-width="14" fill="transparent"/>
                    <circle class="progress-ring-bar" id="progressRingBar" cx="100" cy="100" r="84" stroke-width="14" fill="transparent" stroke-linecap="round"/>
                </svg>
                <div class="progress-text-overlay">
                    <span class="progress-percentage" id="progressPercentageText" style="font-size: 2.2rem;">0%</span>
                    <span class="progress-fraction" id="progressFractionText" style="font-size: 0.72rem;">0 of 0 Tasks</span>
                </div>
            </div>
        `;
    }

    const percentage = Math.round((completedCount / totalDueToday) * 100);
    const ringBar = document.getElementById('progressRingBar');
    const percentageText = document.getElementById('progressPercentageText');
    const fractionText = document.getElementById('progressFractionText');
    
    if (ringBar) {
        const radius = ringBar.r.baseVal.value;
        const circumference = 2 * Math.PI * radius;
        ringBar.style.strokeDasharray = `${circumference} ${circumference}`;
        
        const offset = circumference - (percentage / 100) * circumference;
        ringBar.style.strokeDashoffset = offset;
        
        // Color theme mapping
        ringBar.classList.remove('stroke-red', 'stroke-amber', 'stroke-green');
        if (badge) {
            badge.classList.remove('state-red', 'state-amber', 'state-green');
        }
        
        if (percentage <= 35) {
            ringBar.classList.add('stroke-red');
            if (badge) badge.classList.add('state-red');
        } else if (percentage <= 75) {
            ringBar.classList.add('stroke-amber');
            if (badge) badge.classList.add('state-amber');
        } else {
            ringBar.classList.add('stroke-green');
            if (badge) badge.classList.add('state-green');
        }
    }
    
    if (percentageText) {
        percentageText.textContent = `${percentage}%`;
    }
    if (badge) {
        badge.textContent = `${percentage}% Done`;
    }
    if (fractionText) {
        fractionText.textContent = `${completedCount} of ${totalDueToday} Task${totalDueToday === 1 ? '' : 's'}`;
    }
}

// Render Minimalist Home Calendar
// Render Minimalist Home Calendar
function renderHomeCalendar() {
    const calendarMonthYear = document.getElementById('calendarMonthYear');
    const calendarDaysGrid = document.getElementById('calendarDaysGrid');
    if (!calendarMonthYear || !calendarDaysGrid) return;
    
    calendarDaysGrid.innerHTML = '';
    
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const todayDate = now.getDate();
    
    // Set Header Month Year
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    calendarMonthYear.textContent = `${monthNames[month]} ${year}`;
    
    // First day of current month
    const firstDay = new Date(year, month, 1).getDay();
    // Total days in current month
    const totalDays = new Date(year, month + 1, 0).getDate();
    // Total days in previous month
    const prevMonthTotalDays = new Date(year, month, 0).getDate();
    
    // Render previous month's ending days
    for (let i = firstDay - 1; i >= 0; i--) {
        const dayNum = prevMonthTotalDays - i;
        const dayCell = document.createElement('span');
        dayCell.className = 'calendar-day other-month';
        dayCell.textContent = dayNum;
        calendarDaysGrid.appendChild(dayCell);
    }
    
    // Render Day numbers for current month
    for (let day = 1; day <= totalDays; day++) {
        const dayCell = document.createElement('span');
        dayCell.className = 'calendar-day';
        dayCell.textContent = day;
        
        if (day === todayDate) {
            dayCell.classList.add('today');
        }
        
        calendarDaysGrid.appendChild(dayCell);
    }

    // Fill remaining grid spaces with next month's days (42 cells total)
    const totalCellsRendered = firstDay + totalDays;
    const remainingCells = 42 - totalCellsRendered;
    for (let day = 1; day <= remainingCells; day++) {
        const dayCell = document.createElement('span');
        dayCell.className = 'calendar-day other-month';
        dayCell.textContent = day;
        calendarDaysGrid.appendChild(dayCell);
    }
}

// Render "Next Up" Task Widget
function renderNextUpTask() {
    const container = document.getElementById('nextUpBody');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Filter out tasks completed today
    const todayStr = new Date().toISOString().split('T')[0];
    const incompleteTasks = tasks.filter(t => {
        if (t.lastCompleted) {
            const compDateStr = new Date(t.lastCompleted).toISOString().split('T')[0];
            if (compDateStr === todayStr) return false; // Already completed today
        }
        
        // Also check if future-snoozed
        if (t.snoozeUntil) {
            if (new Date(t.snoozeUntil) > new Date()) return false;
        }
        
        return true;
    });
    
    if (incompleteTasks.length === 0) {
        container.innerHTML = `
            <div class="next-up-empty">
                <i data-lucide="sparkles"></i>
                <p>All caught up for today!</p>
            </div>
        `;
        refreshIcons();
        return;
    }
    
    // Sort logic: Red status first, Amber second, then green closest due/interval
    incompleteTasks.forEach(t => {
        t._calculatedState = t.state || calculateTaskState(t);
    });
    
    incompleteTasks.sort((a, b) => {
        const priorityScore = (state) => {
            if (state === 'Red') return 1;
            if (state === 'Amber') return 2;
            return 3;
        };
        
        const scoreA = priorityScore(a._calculatedState);
        const scoreB = priorityScore(b._calculatedState);
        
        if (scoreA !== scoreB) {
            return scoreA - scoreB; // Lower score (1=Red, 2=Amber) has priority
        }
        
        // If same state score, sort by due date/interval base
        const getBaseDate = (task) => {
            if (task.type === 'fixed') {
                return new Date(task.dueDate || 0);
            } else {
                const base = task.lastCompleted ? new Date(task.lastCompleted) : new Date(task.createdAt);
                const interval = parseInt(task.intervalDays) || 1;
                base.setDate(base.getDate() + interval);
                return base;
            }
        };
        
        return getBaseDate(a) - getBaseDate(b);
    });
    
    const nextTask = incompleteTasks[0];
    const stateLower = nextTask._calculatedState.toLowerCase();
    
    const metaIcon = nextTask.type === 'interval' ? 'refresh-cw' : 'calendar';
    const metaText = nextTask.type === 'interval' 
        ? `Every ${nextTask.intervalDays} day${nextTask.intervalDays === 1 ? '' : 's'}`
        : `Due: ${nextTask.dueDate}`;
        
    const expectedText = nextTask.type === 'interval'
        ? "Expected next cycle"
        : `Expected: ${nextTask.dueDate}`;
    
    const wrapper = document.createElement('div');
    wrapper.className = 'next-up-card-content';
    wrapper.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">
            <div style="display: flex; flex-direction: column; gap: 4px; min-width: 0; flex-grow: 1;">
                <span class="next-up-task-title" title="${nextTask.name}">${nextTask.name}</span>
                ${nextTask.description ? `<p class="next-up-task-desc">${nextTask.description}</p>` : ''}
            </div>
            <span class="state-badge state-${stateLower}">${nextTask._calculatedState}</span>
        </div>
        <div class="next-up-meta-row">
            <div class="next-up-time-badge" title="${expectedText}">
                <i data-lucide="${metaIcon}"></i>
                <span>${metaText}</span>
            </div>
            <button class="btn btn-primary btn-sm" onclick="completeTask('${nextTask.id}')" style="padding: 5px 10px; font-size: 0.72rem; display: flex; align-items: center; gap: 4px;">
                <i data-lucide="check" style="width: 12px; height: 12px;"></i><span>Complete</span>
            </button>
        </div>
    `;
    
    container.appendChild(wrapper);
    refreshIcons();
}

function renderTasksViewNextTasks() {
    const container = document.getElementById('tasksViewNextTasksGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Filter out tasks completed today
    const todayStr = new Date().toISOString().split('T')[0];
    const incompleteTasks = tasks.filter(t => {
        if (t.lastCompleted) {
            const compDateStr = new Date(t.lastCompleted).toISOString().split('T')[0];
            if (compDateStr === todayStr) return false; // Already completed today
        }
        
        // Also check if future-snoozed
        if (t.snoozeUntil) {
            if (new Date(t.snoozeUntil) > new Date()) return false;
        }
        
        return true;
    });
    
    if (incompleteTasks.length === 0) {
        container.innerHTML = `
            <div class="glass-card" style="grid-column: 1 / -1; padding: 30px; text-align: center; color: var(--text-secondary);">
                <i data-lucide="sparkles" style="width: 28px; height: 28px; margin-bottom: 8px; color: var(--text-muted); display: block; margin-left: auto; margin-right: auto;"></i>
                <p style="font-size: 0.9rem;">All caught up! No tasks left to do.</p>
            </div>
        `;
        refreshIcons();
        return;
    }
    
    // Sort logic: Red status first, Amber second, then green closest due/interval
    incompleteTasks.forEach(t => {
        t._calculatedState = t.state || calculateTaskState(t);
    });
    
    incompleteTasks.sort((a, b) => {
        const priorityScore = (state) => {
            if (state === 'Red') return 1;
            if (state === 'Amber') return 2;
            return 3;
        };
        
        const scoreA = priorityScore(a._calculatedState);
        const scoreB = priorityScore(b._calculatedState);
        
        if (scoreA !== scoreB) {
            return scoreA - scoreB;
        }
        
        const getBaseDate = (task) => {
            if (task.type === 'fixed') {
                return new Date(task.dueDate || 0);
            } else {
                const base = task.lastCompleted ? new Date(task.lastCompleted) : new Date(task.createdAt);
                const interval = parseInt(task.intervalDays) || 1;
                base.setDate(base.getDate() + interval);
                return base;
            }
        };
        
        return getBaseDate(a) - getBaseDate(b);
    });
    
    // Take the top 3 next tasks to display in big boxes
    const nextTasks = incompleteTasks.slice(0, 3);
    
    nextTasks.forEach(task => {
        const stateLower = task._calculatedState.toLowerCase();
        const metaIcon = task.type === 'interval' ? 'refresh-cw' : 'calendar';
        const metaText = task.type === 'interval' 
            ? `Every ${task.intervalDays} day${task.intervalDays === 1 ? '' : 's'}`
            : `Due: ${task.dueDate}`;
            
        const box = document.createElement('div');
        box.className = 'glass-card next-task-big-box';
        box.style.padding = '24px';
        box.style.display = 'flex';
        box.style.flexDirection = 'column';
        box.style.justifyContent = 'space-between';
        box.style.gap = '15px';
        box.style.border = '1px solid var(--border-color)';
        box.style.borderRadius = 'var(--border-radius-lg)';
        box.style.background = 'var(--bg-card)';
        box.style.boxShadow = '0 4px 20px rgba(0,0,0,0.02)';
        box.style.transition = 'transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease';
        
        box.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">
                <div style="display: flex; flex-direction: column; gap: 6px; min-width: 0; flex-grow: 1;">
                    <span style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary); font-weight: 700;">${task.category}</span>
                    <h4 style="font-size: 1.15rem; font-weight: 600; color: var(--text-main); margin: 4px 0 0 0; line-height: 1.3;">${task.name}</h4>
                    ${task.description ? `<p style="font-size: 0.82rem; color: var(--text-secondary); line-height: 1.4; margin: 6px 0 0 0;">${task.description}</p>` : ''}
                </div>
                <span class="state-badge state-${stateLower}">${task._calculatedState}</span>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--border-color); padding-top: 15px; margin-top: 5px;">
                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.78rem; color: var(--text-secondary); font-weight: 600;">
                    <i data-lucide="${metaIcon}" style="width: 14px; height: 14px;"></i>
                    <span>${metaText}</span>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button class="btn btn-primary btn-sm" onclick="completeTask('${task.id}')" style="padding: 6px 12px; font-size: 0.78rem; display: flex; align-items: center; gap: 4px;">
                        <i data-lucide="check" style="width: 13px; height: 13px;"></i><span>Complete</span>
                    </button>
                    <button class="btn btn-secondary btn-sm" onclick="snoozeTask('${task.id}')" style="padding: 6px 12px; font-size: 0.78rem; display: flex; align-items: center; gap: 4px;">
                        <i data-lucide="clock" style="width: 13px; height: 13px;"></i><span>Snooze</span>
                    </button>
                </div>
            </div>
        `;
        container.appendChild(box);
    });
    
    refreshIcons();
}

// Morning Digest Panel Rendering
function renderMorningDigest() {
    const listContainer = document.getElementById('digestList');
    const badge = document.getElementById('digestAlertBadge');
    const summaryText = document.getElementById('digestSummaryText');
    
    if (!listContainer) return;
    listContainer.innerHTML = '';
    
    // Compile warning tasks
    const warningTasks = tasks.filter(t => {
        const state = t.state || calculateTaskState(t);
        return state === 'Red' || state === 'Amber';
    });
    
    const redCount = warningTasks.filter(t => (t.state || calculateTaskState(t)) === 'Red').length;
    const amberCount = warningTasks.filter(t => (t.state || calculateTaskState(t)) === 'Amber').length;
    const totalCount = warningTasks.length;
    
    badge.textContent = `${totalCount} Warning${totalCount === 1 ? '' : 's'}`;
    
    if (totalCount > 0) {
        badge.className = 'badge badge-digest';
        if (redCount > 0) {
            badge.classList.add('red-alert');
        }
        summaryText.innerHTML = `You have <span class="text-red font-bold">${redCount} Red</span> and <span class="text-amber font-bold">${amberCount} Amber</span> task${totalCount === 1 ? '' : 's'} requiring immediate attention.`;
        
        warningTasks.forEach(task => {
            const state = task.state || calculateTaskState(task);
            const stateLower = state.toLowerCase();
            
            const item = document.createElement('div');
            item.className = 'digest-item';
            item.innerHTML = `
                <div class="digest-item-left">
                    <span class="dot dot-${stateLower}"></span>
                    <div class="digest-item-info">
                        <span class="digest-item-name" title="${task.name}">${task.name}</span>
                        <span class="digest-item-meta">
                            <i data-lucide="tag" style="width:12px;height:12px;"></i> ${task.category}
                        </span>
                    </div>
                </div>
                <div class="digest-item-right">
                    <button class="btn-action btn-complete" onclick="completeTask('${task.id}')" title="Complete task">
                        <i data-lucide="check"></i>
                    </button>
                    <button class="btn-action btn-snooze" onclick="snoozeTask('${task.id}')" title="Snooze for 24h">
                        <i data-lucide="clock"></i>
                    </button>
                </div>
            `;
            listContainer.appendChild(item);
        });
    } else {
        badge.className = 'badge badge-digest green-alert';
        summaryText.textContent = "All sorted! You're in the Green. No tasks require attention this morning.";
        listContainer.innerHTML = `
            <div class="digest-empty">
                <i data-lucide="sparkles"></i>
                <p>Everything is under control. You're doing amazing!</p>
            </div>
        `;
    }
    
    refreshIcons();
}

// 4-Sector Task Grid rendering
function renderTaskGrid() {
    const sectors = [
        { name: 'Health & Vitality', id: 'list-health', countId: 'count-health' },
        { name: 'Career & Finance', id: 'list-career', countId: 'count-career' },
        { name: 'Relationships & Social', id: 'list-relationships', countId: 'count-relationships' },
        { name: 'Mind & Environment', id: 'list-mind', countId: 'count-mind' }
    ];
    
    sectors.forEach(sec => {
        const container = document.getElementById(sec.id);
        const countBadge = document.getElementById(sec.countId);
        if (!container) return;
        
        container.innerHTML = '';
        
        // Setup container as dropzone
        container.addEventListener('dragover', handleDragOver);
        container.addEventListener('dragleave', handleDragLeave);
        container.addEventListener('drop', (e) => handleDrop(e, sec.name));
        container.dataset.sector = sec.name;
        
        // Filter tasks for this sector
        let sectorTasks = tasks.filter(t => t.category === sec.name);
        
        // Count total tasks in sector
        const totalSecTasks = sectorTasks.length;
        countBadge.textContent = `${totalSecTasks} Task${totalSecTasks === 1 ? '' : 's'}`;
        
        // Filter by badge state if a specific state filter is active
        if (activeFilter !== 'all') {
            sectorTasks = sectorTasks.filter(t => {
                const state = t.state || calculateTaskState(t);
                return state.toLowerCase() === activeFilter.toLowerCase();
            });
        }

        // Filter by search query
        const searchQuery = document.getElementById('taskSearchInput')?.value.toLowerCase().trim() || '';
        if (searchQuery) {
            sectorTasks = sectorTasks.filter(t => 
                t.name.toLowerCase().includes(searchQuery) || 
                (t.description && t.description.toLowerCase().includes(searchQuery))
            );
        }
        
        if (sectorTasks.length > 0) {
            sectorTasks.forEach((task, idx) => {
                const state = task.state || calculateTaskState(task);
                const stateLower = state.toLowerCase();
                
                const card = document.createElement('div');
                card.className = 'task-card';
                card.draggable = true;
                card.dataset.id = task.id;
                card.dataset.order = task.displayOrder ?? idx;
                
                card.addEventListener('dragstart', handleDragStart);
                card.addEventListener('dragend', handleDragEnd);
                
                const metaText = task.type === 'interval' 
                    ? `Every ${task.intervalDays} day${task.intervalDays === 1 ? '' : 's'}`
                    : `Due: ${task.dueDate}`;
                
                const metaIcon = task.type === 'interval' ? 'refresh-cw' : 'calendar';
                
                let isSnoozed = false;
                if (task.snoozeUntil) {
                    const snoozeDate = new Date(task.snoozeUntil);
                    if (snoozeDate > new Date()) {
                        isSnoozed = true;
                    }
                }
                
                card.innerHTML = `
                    <div class="task-card-top">
                        <div style="display: flex; flex-direction: column; gap: 4px; min-width: 0; flex-grow: 1;">
                            <span class="task-title" title="${task.name}">${task.name}</span>
                            ${task.description ? `<p class="task-desc">${task.description}</p>` : ''}
                        </div>
                        <span class="state-badge state-${stateLower}">${state}</span>
                    </div>
                    <div class="task-meta">
                        <div class="task-meta-left">
                            <span class="task-meta-item">
                                <i data-lucide="${metaIcon}"></i>
                                <span>${metaText}</span>
                            </span>
                            ${task.lastCompleted ? `
                            <span class="task-meta-item text-green" title="Last completed today/recently">
                                <i data-lucide="check-circle"></i>
                                <span>Done</span>
                            </span>` : ''}
                            ${isSnoozed ? `
                            <span class="task-meta-item text-amber" title="Snoozed until tomorrow">
                                <i data-lucide="bell-off"></i>
                                <span>Snoozed</span>
                            </span>` : ''}
                        </div>
                        <div class="task-actions">
                            <button class="btn-action btn-complete" onclick="completeTask('${task.id}')" title="Complete task">
                                <i data-lucide="check"></i>
                            </button>
                            <button class="btn-action btn-snooze" onclick="snoozeTask('${task.id}')" title="Snooze for 24h">
                                <i data-lucide="clock"></i>
                            </button>
                            <button class="btn-action btn-edit" onclick="openEditTaskModal('${task.id}')" title="Edit task">
                                <i data-lucide="edit-2"></i>
                            </button>
                            <button class="btn-action btn-delete" onclick="deleteTask('${task.id}')" title="Delete task">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        } else {
            container.innerHTML = `
                <div class="task-empty">
                    <i data-lucide="clipboard-list"></i>
                    <p>No tasks found</p>
                </div>
            `;
        }
    });
    
    refreshIcons();
    refreshIcons();
}

// 4.5 Drag and Drop Handlers
let draggedCard = null;

function handleDragStart(e) {
    draggedCard = this;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', this.dataset.id);
    setTimeout(() => this.classList.add('dragging'), 0);
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
    document.querySelectorAll('.task-list').forEach(col => col.classList.remove('drag-over'));
    draggedCard = null;
}

function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    this.classList.add('drag-over');

    const afterElement = getDragAfterElement(this, e.clientY);
    if (draggedCard) {
        if (afterElement == null) {
            this.appendChild(draggedCard);
        } else {
            this.insertBefore(draggedCard, afterElement);
        }
    }
}

function handleDragLeave(e) {
    if (!this.contains(e.relatedTarget)) {
        this.classList.remove('drag-over');
    }
}

async function handleDrop(e, targetSector) {
    e.preventDefault();
    this.classList.remove('drag-over');
    
    if (!draggedCard) return;

    // Collect all card IDs in this container to send new order to backend
    const cardElements = [...this.querySelectorAll('.task-card')];
    const updateRequests = cardElements.map((card, index) => ({
        id: parseTaskId(card.dataset.id),
        order: index,
        sector: targetSector
    }));

    // Optimistically update local array
    const taskId = parseTaskId(draggedCard.dataset.id);
    const taskObj = tasks.find(t => t.id == taskId);
    if (taskObj) {
        taskObj.category = targetSector;
        // Re-sort the local tasks array
        updateRequests.forEach(req => {
            const t = tasks.find(x => x.id == req.id);
            if (t) t.displayOrder = req.order;
        });
        tasks.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
    }

    try {
        await apiRequest('/tasks/reorder', 'PUT', updateRequests);
        // We do not re-render grid instantly to prevent visual stutter, 
        // since the DOM is already correctly mutated.
    } catch (err) {
        console.error('Failed to save new task order', err);
        showToast("Error saving task order", "error");
        await loadDashboardData(); // Revert on failure
    }
}

// Quick Complete Dropzone
document.addEventListener('DOMContentLoaded', () => {
    const progressPanel = document.querySelector('.progress-panel');
    if (progressPanel) {
        progressPanel.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            progressPanel.classList.add('quick-complete-drag-over');
        });
        progressPanel.addEventListener('dragleave', (e) => {
            progressPanel.classList.remove('quick-complete-drag-over');
        });
        progressPanel.addEventListener('drop', async (e) => {
            e.preventDefault();
            progressPanel.classList.remove('quick-complete-drag-over');
            if (draggedCard) {
                const taskId = draggedCard.dataset.id;
                await completeTask(taskId);
            }
        });
    }
});

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.task-card:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

// 5. SVG Consistency Chart rendering
let activeTooltip = null;

function renderAnalyticsGraph() {
    const wrapper = document.getElementById('svgWrapper');
    if (!wrapper) return;
    
    wrapper.innerHTML = '';
    
    if (!historyData || historyData.length === 0) {
        wrapper.innerHTML = `
            <div class="digest-empty">
                <i data-lucide="info"></i>
                <p>No analytics history logs found.</p>
            </div>
        `;
        refreshIcons();
        return;
    }
    
    // Sort history chronologically by date
    let sortedHistory = [...historyData].sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Slice to the requested range (last 7 or 30 days)
    sortedHistory = sortedHistory.slice(-chartRange);
    
    const width = wrapper.clientWidth || 500;
    const height = 180;
    
    const paddingLeft = 45;
    const paddingRight = 20;
    const paddingTop = 20;
    const paddingBottom = 30;
    
    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;
    
    // SVG element creation
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.style.overflow = "visible";
    
    // Grid Lines (Horizontal Levels)
    const gridLevels = [0, 25, 50, 75, 100];
    gridLevels.forEach(level => {
        const y = paddingTop + chartHeight - (level / 100) * chartHeight;
        
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", paddingLeft);
        line.setAttribute("y1", y);
        line.setAttribute("x2", width - paddingRight);
        line.setAttribute("y2", y);
        line.setAttribute("stroke", "var(--chart-grid)");
        line.setAttribute("stroke-width", "1");
        if (level > 0 && level < 100) {
            line.setAttribute("stroke-dasharray", "4,4");
        }
        svg.appendChild(line);
        
        const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
        label.setAttribute("x", paddingLeft - 10);
        label.setAttribute("y", y + 4);
        label.setAttribute("text-anchor", "end");
        label.setAttribute("fill", "var(--text-secondary)");
        label.setAttribute("font-size", "10px");
        label.setAttribute("font-weight", "500");
        label.textContent = `${level}%`;
        svg.appendChild(label);
    });
    
    // Convert history logs to coordinate points
    const points = sortedHistory.map((d, index) => {
        const x = paddingLeft + (index / Math.max(1, sortedHistory.length - 1)) * chartWidth;
        const y = paddingTop + chartHeight - (d.rate / 100) * chartHeight;
        return { x, y, date: d.date, rate: d.rate, completed: d.completed, total: d.total };
    });
    
    // Area Gradient Definition
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    const gradient = document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");
    gradient.setAttribute("id", "svg-glow-gradient");
    gradient.setAttribute("x1", "0");
    gradient.setAttribute("y1", "0");
    gradient.setAttribute("x2", "0");
    gradient.setAttribute("y2", "1");
    
    const stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
    stop1.setAttribute("offset", "0%");
    stop1.setAttribute("stop-color", "var(--color-primary-light)");
    stop1.setAttribute("stop-opacity", "0.3");
    
    const stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
    stop2.setAttribute("offset", "100%");
    stop2.setAttribute("stop-color", "var(--color-primary-light)");
    stop2.setAttribute("stop-opacity", "0.0");
    
    gradient.appendChild(stop1);
    gradient.appendChild(stop2);
    defs.appendChild(gradient);
    svg.appendChild(defs);
    
    // Draw area path below the curve
    if (points.length > 1) {
        let areaD = `M ${points[0].x} ${paddingTop + chartHeight}`;
        points.forEach(p => {
            areaD += ` L ${p.x} ${p.y}`;
        });
        areaD += ` L ${points[points.length - 1].x} ${paddingTop + chartHeight} Z`;
        
        const areaPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
        areaPath.setAttribute("d", areaD);
        areaPath.setAttribute("fill", "url(#svg-glow-gradient)");
        svg.appendChild(areaPath);
    }
    
    // Draw line curve path
    if (points.length > 1) {
        let lineD = `M ${points[0].x} ${points[0].y}`;
        for (let i = 1; i < points.length; i++) {
            lineD += ` L ${points[i].x} ${points[i].y}`;
        }
        
        const linePath = document.createElementNS("http://www.w3.org/2000/svg", "path");
        linePath.setAttribute("d", lineD);
        linePath.setAttribute("fill", "none");
        linePath.setAttribute("stroke", "var(--color-primary-light)");
        linePath.setAttribute("stroke-width", "3");
        linePath.setAttribute("stroke-linecap", "round");
        linePath.setAttribute("stroke-linejoin", "round");
        linePath.setAttribute("filter", "drop-shadow(0px 3px 5px var(--color-primary-glow))");
        svg.appendChild(linePath);
    }
    
    // Draw point interactive nodes and label values
    points.forEach((p, idx) => {
        // Glowing halo circle on hover
        const halo = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        halo.setAttribute("cx", p.x);
        halo.setAttribute("cy", p.y);
        halo.setAttribute("r", "8");
        halo.setAttribute("fill", "var(--color-primary-light)");
        halo.setAttribute("opacity", "0");
        halo.style.transition = "opacity 0.2s ease";
        svg.appendChild(halo);
        
        // Solid center point
        const dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        dot.setAttribute("cx", p.x);
        dot.setAttribute("cy", p.y);
        dot.setAttribute("r", "4.5");
        dot.setAttribute("fill", "var(--bg-dark-gray)");
        dot.setAttribute("stroke", "var(--color-primary-light)");
        dot.setAttribute("stroke-width", "2.5");
        dot.style.cursor = "pointer";
        svg.appendChild(dot);
        
        // X-axis text labeling
        const xLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
        xLabel.setAttribute("x", p.x);
        xLabel.setAttribute("y", paddingTop + chartHeight + 18);
        xLabel.setAttribute("text-anchor", "middle");
        xLabel.setAttribute("fill", "var(--text-secondary)");
        xLabel.setAttribute("font-size", "9px");
        xLabel.setAttribute("font-weight", "500");
        
        // Show weekdays for 7-day range, date numbers for 30-day range
        const parsedDate = new Date(p.date + 'T00:00:00');
        if (chartRange <= 7) {
            xLabel.textContent = parsedDate.toLocaleDateString(undefined, { weekday: 'short' });
        } else {
            // Show label for every 4th day to prevent text overlaps
            if (idx % 4 === 0 || idx === points.length - 1) {
                xLabel.textContent = parsedDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
            } else {
                xLabel.textContent = '';
            }
        }
        svg.appendChild(xLabel);
        
        // Transparent thick circle overlay for mouse triggers
        const hoverArea = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        hoverArea.setAttribute("cx", p.x);
        hoverArea.setAttribute("cy", p.y);
        hoverArea.setAttribute("r", "15");
        hoverArea.setAttribute("fill", "transparent");
        hoverArea.style.cursor = "pointer";
        
        hoverArea.addEventListener('mouseenter', (e) => {
            halo.setAttribute("opacity", "0.4");
            dot.setAttribute("r", "5.5");
            dot.setAttribute("fill", "var(--color-primary-light)");
            showChartTooltip(e, p);
        });
        
        hoverArea.addEventListener('mouseleave', () => {
            halo.setAttribute("opacity", "0");
            dot.setAttribute("r", "4.5");
            dot.setAttribute("fill", "var(--bg-dark-gray)");
            hideChartTooltip();
        });
        
        svg.appendChild(hoverArea);
    });
    
    wrapper.appendChild(svg);
}

// Tooltip helpers
function showChartTooltip(event, point) {
    hideChartTooltip();
    
    const wrapper = document.getElementById('svgWrapper');
    const tooltip = document.createElement('div');
    tooltip.className = 'chart-tooltip';
    
    const parsedDate = new Date(point.date + 'T00:00:00');
    const formattedDate = parsedDate.toLocaleDateString(undefined, { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric',
        year: 'numeric' 
    });
    
    tooltip.innerHTML = `
        <span class="chart-tooltip-date">${formattedDate}</span>
        <span class="chart-tooltip-value">Compliance: ${point.rate}%</span>
        <span class="chart-tooltip-detail" style="font-size: 0.7rem; color: var(--text-secondary);">
            Done: ${point.completed} / Total due: ${point.total}
        </span>
    `;
    
    wrapper.appendChild(tooltip);
    
    const wrapperRect = wrapper.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    const left = point.x - (tooltipRect.width / 2);
    const top = point.y - tooltipRect.height - 10;
    
    tooltip.style.left = `${Math.max(5, Math.min(left, wrapperRect.width - tooltipRect.width - 5))}px`;
    tooltip.style.top = `${Math.max(5, top)}px`;
    
    activeTooltip = tooltip;
}

function hideChartTooltip() {
    if (activeTooltip) {
        activeTooltip.remove();
        activeTooltip = null;
    }
}

// 6. Action Handlers

// Complete Task Action
async function completeTask(id) {
    try {
        await apiRequest(`/tasks/${id}/complete`, 'POST');
        showToast("Task completed! Streak updated.");
        await loadDashboardData();
    } catch (err) {
        console.error("Failed completing task.", err);
        showToast("Error completing task", "error");
    }
}

async function snoozeTask(id) {
    try {
        const durationHours = parseInt(localStorage.getItem('bokea_default_snooze')) || 24;
        await apiRequest(`/tasks/${id}/snooze`, 'POST', { durationHours });
        showToast(`Task snoozed for ${durationHours} hours.`);
        await loadDashboardData();
    } catch (err) {
        console.error("Failed snoozing task.", err);
        showToast("Error snoozing task", "error");
    }
}

// Delete Task Action (Frontend only / local storage fallback support)
async function deleteTask(id) {
    if (!confirm("Are you sure you want to permanently delete this task?")) {
        return;
    }
    
    try {
        await apiRequest(`/tasks/${id}`, 'DELETE');
        // Delete duration
        const durations = JSON.parse(localStorage.getItem('bokea_task_durations') || '{}');
        delete durations[id];
        localStorage.setItem('bokea_task_durations', JSON.stringify(durations));
        showToast("Task deleted successfully.");
        await loadDashboardData();
    } catch (err) {
        console.error("Failed deleting task.", err);
        showToast("Error deleting task", "error");
    }
}

// 7. Modals and Creation Form Logic

const modal = document.getElementById('taskModal');
const taskForm = document.getElementById('taskForm');
const intervalGroup = document.getElementById('intervalGroup');
const dueDateGroup = document.getElementById('dueDateGroup');

let currentStep = 1;

function showStep(stepNum) {
    const prevStep = currentStep;
    currentStep = stepNum;
    
    // Check if the modal is currently open. If not, we perform a silent update without animations.
    const isModalOpen = modal && modal.classList.contains('open');
    const silent = !isModalOpen;
    
    const direction = stepNum > prevStep ? 'forward' : 'backward';
    
    document.querySelectorAll('.wizard-step').forEach(step => {
        const num = parseInt(step.getAttribute('data-step'));
        
        // Reset classes
        step.className = 'wizard-step';
        
        if (num === stepNum) {
            step.classList.add('wizard-step-active');
            if (!silent && prevStep !== stepNum) {
                step.classList.add(direction === 'forward' ? 'slide-in-right' : 'slide-in-left');
            }
        } else if (num === prevStep && !silent && prevStep !== stepNum) {
            step.classList.add(direction === 'forward' ? 'slide-out-left' : 'slide-out-right');
        } else {
            step.classList.add('hidden-step');
        }
    });
    
    // Progress Bar and Label (0% for step 1, 33.3% for step 2, 66.6% for step 3, 100% for step 4)
    const progressPercent = ((stepNum - 1) / 3) * 100;
    const progressBar = document.getElementById('wizardProgressBar');
    if (progressBar) progressBar.style.width = `${progressPercent}%`;
    
    const stepLabel = document.getElementById('wizardStepLabel');
    if (stepLabel) stepLabel.textContent = `Step ${stepNum} of 4`;
    
    // Update visual nodes
    document.querySelectorAll('.wizard-step-node').forEach(node => {
        const stepVal = parseInt(node.getAttribute('data-step'));
        node.classList.remove('active', 'completed');
        
        node.style.borderColor = 'var(--border-color)';
        node.style.background = 'var(--bg-card)';
        node.style.color = 'var(--text-secondary)';
        
        if (stepVal === stepNum) {
            node.classList.add('active');
            node.style.borderColor = 'var(--color-primary-light)';
            node.style.color = 'var(--color-primary-light)';
        } else if (stepVal < stepNum) {
            node.classList.add('completed');
            node.style.borderColor = 'var(--color-primary-light)';
            node.style.background = 'var(--color-primary-light)';
            node.style.color = '#ffffff';
        }
    });

    // Navigation buttons
    const prevBtn = document.getElementById('prevStepBtn');
    const nextBtn = document.getElementById('nextStepBtn');
    const saveBtn = document.getElementById('saveTaskBtn');
    
    if (prevBtn) {
        prevBtn.style.visibility = stepNum === 1 ? 'hidden' : 'visible';
    }
    
    if (stepNum === 4) {
        if (nextBtn) nextBtn.classList.add('hidden');
        if (saveBtn) saveBtn.classList.remove('hidden');
    } else {
        if (nextBtn) nextBtn.classList.remove('hidden');
        if (saveBtn) saveBtn.classList.add('hidden');
    }
}

// Wire wizard option click event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Step 1 Category Buttons
    document.querySelectorAll('.wizard-step[data-step="1"] .wizard-option-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.wizard-step[data-step="1"] .wizard-option-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const catVal = btn.getAttribute('data-value');
            document.getElementById('taskCategory').value = catVal;
            
            syncTaskNameUI(catVal);
            
            // Auto advance to step 2 after a small delay for delightful feedback
            setTimeout(() => {
                if (currentStep === 1) showStep(2);
            }, 250);
        });
    });

    // Task Name Select dropdown change listener
    const taskNameSelect = document.getElementById('taskNameSelect');
    if (taskNameSelect) {
        taskNameSelect.addEventListener('change', () => {
            const selectedOpt = taskNameSelect.options[taskNameSelect.selectedIndex];
            if (!selectedOpt || !selectedOpt.value) {
                document.getElementById('taskName').value = "";
                return;
            }

            const name = selectedOpt.getAttribute('data-name');
            const desc = selectedOpt.getAttribute('data-desc');
            const dur = selectedOpt.getAttribute('data-duration');
            
            document.getElementById('taskName').value = name;
            document.getElementById('taskDescription').value = desc;
            
            const durInput = document.getElementById('taskDuration');
            if (durInput) durInput.value = dur;
            
            document.getElementById('taskName').classList.remove('input-error');
        });
    }

    // Step 3 Frequency Buttons
    document.querySelectorAll('.wizard-step[data-step="3"] .wizard-option-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.wizard-step[data-step="3"] .wizard-option-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const freqType = btn.getAttribute('data-freq-type');
            document.getElementById('taskType').value = freqType === 'fixed' ? 'fixed' : 'interval';
            
            const freqVal = btn.getAttribute('data-freq-val');
            if (freqVal) {
                document.getElementById('taskInterval').value = freqVal;
            }
            
            // Toggle input groups
            if (freqType === 'custom') {
                intervalGroup.classList.remove('hidden');
                dueDateGroup.classList.add('hidden');
                setTimeout(() => {
                    const input = document.getElementById('taskInterval');
                    if (input) input.focus({ preventScroll: true });
                }, 50);
            } else if (freqType === 'fixed') {
                intervalGroup.classList.add('hidden');
                dueDateGroup.classList.remove('hidden');
                setTimeout(() => {
                    const input = document.getElementById('taskDueDate');
                    if (input) input.focus({ preventScroll: true });
                }, 50);
            } else {
                intervalGroup.classList.add('hidden');
                dueDateGroup.classList.add('hidden');
                // Auto advance since it's a fixed standard interval (daily, weekly, monthly)
                setTimeout(() => {
                    if (currentStep === 3) showStep(4);
                }, 250);
            }
        });
    });

    // Step 4 Notification Buttons
    document.querySelectorAll('.wizard-step[data-step="4"] .wizard-option-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.wizard-step[data-step="4"] .wizard-option-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('taskNotify').value = btn.getAttribute('data-value');
        });
    });

    // Input event listeners to clear error outlines
    document.getElementById('taskName').addEventListener('input', (e) => e.target.classList.remove('input-error'));
    document.getElementById('taskNameSelect').addEventListener('change', (e) => e.target.classList.remove('input-error'));
    document.getElementById('taskDueDate').addEventListener('input', (e) => e.target.classList.remove('input-error'));
    document.getElementById('taskInterval').addEventListener('input', (e) => e.target.classList.remove('input-error'));

    // Prevent premature form submission on Enter key press
    const taskFormEl = document.getElementById('taskForm');
    if (taskFormEl) {
        taskFormEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                if (e.target.tagName.toLowerCase() === 'textarea') return;
                e.preventDefault();
                if (currentStep < 4) {
                    document.getElementById('nextStepBtn').click();
                } else {
                    const saveBtn = document.getElementById('saveTaskBtn');
                    if (saveBtn) saveBtn.click();
                }
            }
        });
    }

    // Clickable progress step nodes
    document.querySelectorAll('.wizard-step-node').forEach(node => {
        node.addEventListener('click', () => {
            const targetStep = parseInt(node.getAttribute('data-step'));
            if (targetStep < currentStep) {
                showStep(targetStep);
            } else if (targetStep > currentStep) {
                // Validate intermediate steps before allowing jumping forward
                let valid = true;
                
                // Validate step 2 details
                if (currentStep === 2 || (currentStep < 2 && targetStep > 2)) {
                    const isSelect = document.getElementById('taskNameInputGroup').style.display === 'none';
                    const nameEl = document.getElementById(isSelect ? 'taskNameSelect' : 'taskName');
                    if (!nameEl.value.trim()) {
                        nameEl.classList.add('input-error');
                        showToast(isSelect ? "Please select a task name" : "Please enter a task name", "error");
                        valid = false;
                    }
                }
                
                // Validate step 3 details
                if (valid && (currentStep === 3 || (currentStep < 3 && targetStep > 3))) {
                    const type = document.getElementById('taskType').value;
                    if (type === 'fixed') {
                        const dateEl = document.getElementById('taskDueDate');
                        if (!dateEl.value) {
                            dateEl.classList.add('input-error');
                            showToast("Please select a due date", "error");
                            valid = false;
                        }
                    } else {
                        const intervalEl = document.getElementById('taskInterval');
                        if (!intervalEl.value || intervalEl.value < 1) {
                            intervalEl.classList.add('input-error');
                            showToast("Please enter an interval of at least 1 day", "error");
                            valid = false;
                        }
                    }
                }
                
                if (valid) {
                    showStep(targetStep);
                }
            }
        });
    });

    // Next/Prev Buttons click actions
    document.getElementById('nextStepBtn').addEventListener('click', () => {
        if (currentStep === 2) {
            // Validate Step 2 details
            const isSelect = document.getElementById('taskNameInputGroup').style.display === 'none';
            const nameEl = document.getElementById(isSelect ? 'taskNameSelect' : 'taskName');
            const name = nameEl.value.trim();
            if (!name) {
                nameEl.classList.add('input-error');
                showToast(isSelect ? "Please select a task name" : "Please enter a task name", "error");
                return;
            }
        } else if (currentStep === 3) {
            // Validate Step 3 details if visible
            const type = document.getElementById('taskType').value;
            if (type === 'fixed') {
                const dateEl = document.getElementById('taskDueDate');
                const dueDate = dateEl.value;
                if (!dueDate) {
                    dateEl.classList.add('input-error');
                    showToast("Please select a due date", "error");
                    return;
                }
            } else {
                // interval
                const intervalEl = document.getElementById('taskInterval');
                const intervalDays = intervalEl.value;
                if (!intervalDays || intervalDays < 1) {
                    intervalEl.classList.add('input-error');
                    showToast("Please enter an interval of at least 1 day", "error");
                    return;
                }
            }
        }
        
        if (currentStep < 4) {
            showStep(currentStep + 1);
        }
    });

    document.getElementById('prevStepBtn').addEventListener('click', () => {
        if (currentStep > 1) {
            showStep(currentStep - 1);
        }
    });
});

// Helper to clear error highlights
function clearValidationErrors() {
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
}

// Show/hide taskName select or input based on category
function syncTaskNameUI(category) {
    const inputGroup = document.getElementById('taskNameInputGroup');
    const selectGroup = document.getElementById('taskNameSelectGroup');
    const selectEl = document.getElementById('taskNameSelect');
    const inputEl = document.getElementById('taskName');
    
    if (category === 'Health & Vitality') {
        if (inputGroup) inputGroup.style.display = 'none';
        if (selectGroup) selectGroup.style.display = 'block';
        if (inputEl) inputEl.required = false;
        if (selectEl) selectEl.required = true;
        
        // Try to match the current value of inputEl to one of the select options
        if (selectEl && inputEl) {
            let matched = false;
            for (let i = 0; i < selectEl.options.length; i++) {
                const opt = selectEl.options[i];
                if (opt.getAttribute('data-name') === inputEl.value) {
                    selectEl.selectedIndex = i;
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                selectEl.value = "";
            }
        }
    } else {
        if (inputGroup) inputGroup.style.display = 'block';
        if (selectGroup) selectGroup.style.display = 'none';
        if (inputEl) inputEl.required = true;
        if (selectEl) selectEl.required = false;
        if (selectEl) selectEl.value = "";
    }
}

// Open create modal
function openCreateTaskModal(category) {
    clearValidationErrors();
    document.getElementById('modalTitle').textContent = "Create Task";
    document.getElementById('taskId').value = "";
    document.getElementById('taskName').value = "";
    document.getElementById('taskDuration').value = "0";
    
    const cat = category || "Health & Vitality";
    document.getElementById('taskCategory').value = cat;
    
    syncTaskNameUI(cat);
    
    // Sync Category Step 1 button active state
    document.querySelectorAll('.wizard-step[data-step="1"] .wizard-option-btn').forEach(btn => {
        if (btn.getAttribute('data-value') === cat) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    // Sync Frequency Step 3 button active state (Default is Daily = 1 day interval)
    document.querySelectorAll('.wizard-step[data-step="3"] .wizard-option-btn').forEach(btn => {
        if (btn.getAttribute('data-freq-type') === 'interval' && btn.getAttribute('data-freq-val') === '1') {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    // Sync Notify Step 4 button active state (Default is digest)
    document.querySelectorAll('.wizard-step[data-step="4"] .wizard-option-btn').forEach(btn => {
        if (btn.getAttribute('data-value') === 'digest') {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    intervalGroup.classList.add('hidden');
    dueDateGroup.classList.add('hidden');

    showStep(1);
    modal.classList.add('open');
}

// Open edit modal
function openEditTaskModal(id) {
    clearValidationErrors();
    const task = tasks.find(t => t.id == id);
    if (!task) return;
    
    document.getElementById('modalTitle').textContent = "Edit Task";
    document.getElementById('taskId').value = task.id;
    document.getElementById('taskName').value = task.name;
    document.getElementById('taskCategory').value = task.category;
    document.getElementById('taskDescription').value = task.description || "";
    document.getElementById('taskType').value = task.type;
    
    document.getElementById('taskDuration').value = task.durationMinutes || "0";
    
    syncTaskNameUI(task.category);
    
    // Sync Category Step 1 button active state
    document.querySelectorAll('.wizard-step[data-step="1"] .wizard-option-btn').forEach(btn => {
        if (btn.getAttribute('data-value') === task.category) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    // Sync Frequency Step 3 button active state
    document.querySelectorAll('.wizard-step[data-step="3"] .wizard-option-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    if (task.type === 'interval') {
        const interval = task.intervalDays || 1;
        document.getElementById('taskInterval').value = interval;
        document.getElementById('taskDueDate').value = "";
        
        if (interval === 1) {
            const btn = document.querySelector('.wizard-step[data-step="3"] .wizard-option-btn[data-freq-val="1"]');
            if (btn) btn.classList.add('active');
            intervalGroup.classList.add('hidden');
            dueDateGroup.classList.add('hidden');
        } else if (interval === 7) {
            const btn = document.querySelector('.wizard-step[data-step="3"] .wizard-option-btn[data-freq-val="7"]');
            if (btn) btn.classList.add('active');
            intervalGroup.classList.add('hidden');
            dueDateGroup.classList.add('hidden');
        } else if (interval === 30) {
            const btn = document.querySelector('.wizard-step[data-step="3"] .wizard-option-btn[data-freq-val="30"]');
            if (btn) btn.classList.add('active');
            intervalGroup.classList.add('hidden');
            dueDateGroup.classList.add('hidden');
        } else {
            const btn = document.getElementById('btnCustomDays');
            if (btn) btn.classList.add('active');
            intervalGroup.classList.remove('hidden');
            dueDateGroup.classList.add('hidden');
        }
    } else {
        document.getElementById('taskDueDate').value = task.dueDate || "";
        document.getElementById('taskInterval').value = "1";
        
        const btn = document.getElementById('btnFixedDate');
        if (btn) btn.classList.add('active');
        intervalGroup.classList.add('hidden');
        dueDateGroup.classList.remove('hidden');
    }
    
    // Sync Notify Step 4 button active state (Since tasks might not have it saved, default to digest unless specified)
    const notifyPref = task.notifyPreference || 'digest';
    document.getElementById('taskNotify').value = notifyPref;
    
    document.querySelectorAll('.wizard-step[data-step="4"] .wizard-option-btn').forEach(btn => {
        if (btn.getAttribute('data-value') === notifyPref) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    showStep(1);
    modal.classList.add('open');
}

// Close modal
function closeModal() {
    modal.classList.remove('open');
}


// Form Submission (Add or Edit)
taskForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const id = document.getElementById('taskId').value;
    const name = document.getElementById('taskName').value.trim();
    const category = document.getElementById('taskCategory').value;
    const description = document.getElementById('taskDescription').value.trim();
    const type = document.getElementById('taskType').value;
    const intervalDays = document.getElementById('taskInterval').value;
    const dueDate = document.getElementById('taskDueDate').value;
    const durationMinutes = document.getElementById('taskDuration') ? parseInt(document.getElementById('taskDuration').value) || 0 : 0;
    
    if (!name) {
        showToast("Task name is required", "error");
        return;
    }
    
    if (type === 'fixed' && !dueDate) {
        showToast("Due date is required for fixed date tasks", "error");
        return;
    }
    
    const payload = {
        name,
        category,
        description,
        type,
        intervalDays: type === 'interval' ? parseInt(intervalDays) || 1 : null,
        dueDate: type === 'fixed' ? dueDate : null
    };
    
    try {
        let savedTask = null;
        if (id) {
            // Edit
            savedTask = await apiRequest(`/tasks/${id}`, 'PUT', payload);
            showToast("Task updated successfully.");
        } else {
            // Create
            savedTask = await apiRequest('/tasks', 'POST', payload);
            showToast("Task created successfully.");
        }
        
        // Save duration to localStorage
        const taskObj = savedTask || { id: id };
        if (taskObj && taskObj.id) {
            const durations = JSON.parse(localStorage.getItem('bokea_task_durations') || '{}');
            durations[taskObj.id] = durationMinutes;
            localStorage.setItem('bokea_task_durations', JSON.stringify(durations));
        }
        
        closeModal();
        await loadDashboardData();
    } catch (err) {
        console.error("Error saving task.", err);
        showToast("Error saving task", "error");
    }
});

// 8. Toast Notifications
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    
    toast.textContent = message;
    toast.className = 'toast';
    
    if (type === 'error') {
        toast.classList.add('toast-error');
    } else if (type === 'warning') {
        toast.classList.add('toast-error'); // Reuse styling with variations if needed
        toast.style.borderColor = 'var(--color-amber)';
        toast.style.boxShadow = '0 10px 30px rgba(255, 183, 3, 0.2)';
    }
    
    toast.classList.remove('hidden');
    
    // Auto-dismiss
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}

// 9. Startup & Event Listeners Wiring

document.addEventListener('DOMContentLoaded', () => {
    // Welcome Screen & Auth logic
    const welcomeScreen = document.getElementById('welcomeScreen');
    const loginFormSection = document.getElementById('loginFormSection');
    const registerFormSection = document.getElementById('registerFormSection');
    const showRegisterLink = document.getElementById('showRegisterLink');
    const showLoginLink = document.getElementById('showLoginLink');
    const authErrorMsg = document.getElementById('authErrorMsg');
    const dashboardGreeting = document.getElementById('dashboardGreeting');
    const dashboardUserName = document.getElementById('userName');

    function updateGreetings(name) {
        const hour = new Date().getHours();
        let greetText = "Good night";
        if (hour >= 5 && hour < 12) {
            greetText = "Good morning";
        } else if (hour >= 12 && hour < 17) {
            greetText = "Good afternoon";
        } else if (hour >= 17 && hour < 21) {
            greetText = "Good evening";
        }
        
        const displayName = (name && name !== 'User' && name !== 'Productive Mind') ? name : 'Ajay';
        const firstName = displayName.split(' ')[0];
        
        if (dashboardGreeting) dashboardGreeting.textContent = greetText;
        if (dashboardUserName) dashboardUserName.textContent = firstName;
        
        const sidebarUser = document.querySelector('.username');
        if (sidebarUser) sidebarUser.textContent = displayName;
        const avatar = document.querySelector('.avatar');
        if (avatar) avatar.textContent = firstName.charAt(0).toUpperCase();
        const topAvatar = document.querySelector('.profile-avatar-initial');
        if (topAvatar) topAvatar.textContent = firstName.charAt(0).toUpperCase();
    }

    function calculateSleepDuration(bedTime, wakeTime) {
        if (!bedTime || !wakeTime) return 0;
        const [bedH, bedM] = bedTime.split(':').map(Number);
        const [wakeH, wakeM] = wakeTime.split(':').map(Number);
        let bedMinutes = bedH * 60 + bedM;
        let wakeMinutes = wakeH * 60 + wakeM;
        let diff = wakeMinutes - bedMinutes;
        if (diff < 0) diff += 24 * 60;
        return diff / 60;
    }

    function updateSleepHealthMeter(bedTimeEl, wakeTimeEl, textEl, labelEl, barEl, tipsEl) {
        const duration = calculateSleepDuration(bedTimeEl.value, wakeTimeEl.value);
        textEl.textContent = `Sleep Duration: ${duration.toFixed(1)} hours`;
        labelEl.className = 'health-badge';
        barEl.className = 'meter-bar-fill';
        
        if (duration >= 7 && duration <= 9) {
            labelEl.textContent = 'Optimal Sleep';
            labelEl.classList.add('health-optimal');
            barEl.classList.add('health-optimal');
            barEl.style.width = '100%';
            tipsEl.textContent = '7 to 9 hours is the ideal sleep window for adults to maintain metabolic and cognitive health.';
        } else if ((duration >= 6 && duration < 7) || (duration > 9 && duration <= 10)) {
            labelEl.textContent = 'Marginal Sleep';
            labelEl.classList.add('health-warning');
            barEl.classList.add('health-warning');
            barEl.style.width = '70%';
            tipsEl.textContent = 'Sleeping slightly less or more than recommended can lead to midday fatigue or subtle cognitive changes.';
        } else {
            labelEl.textContent = 'Unhealthy Sleep';
            labelEl.classList.add('health-danger');
            barEl.classList.add('health-danger');
            barEl.style.width = '40%';
            if (duration < 6) {
                tipsEl.textContent = 'Less than 6 hours of sleep puts you at high risk of chronic sleep deprivation, reduced cognitive focus, and high stress levels.';
            } else {
                tipsEl.textContent = 'Oversleeping (more than 10 hours) can be a sign of poor sleep quality, sleep apnea, or underlying fatigue.';
            }
        }
    }

    function initSetupPageListeners() {
        const setupBedTime = document.getElementById('setupBedTime');
        const setupWakeUpTime = document.getElementById('setupWakeUpTime');
        const textEl = document.getElementById('sleepDurationText');
        const labelEl = document.getElementById('sleepHealthLabel');
        const barEl = document.getElementById('sleepHealthBar');
        const tipsEl = document.getElementById('sleepHealthTips');

        if (setupBedTime && setupWakeUpTime && textEl && labelEl && barEl && tipsEl) {
            const triggerUpdate = () => {
                updateSleepHealthMeter(setupBedTime, setupWakeUpTime, textEl, labelEl, barEl, tipsEl);
            };
            setupBedTime.addEventListener('input', triggerUpdate);
            setupWakeUpTime.addEventListener('input', triggerUpdate);
            triggerUpdate();
        }

        const setupForm = document.getElementById('setupForm');
        if (setupForm) {
            setupForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const bedTime = document.getElementById('setupBedTime').value;
                const wakeUpTime = document.getElementById('setupWakeUpTime').value;
                const workStartTime = document.getElementById('setupWorkStart').value;
                const workEndTime = document.getElementById('setupWorkEnd').value;
                
                const workDays = [];
                document.querySelectorAll('input[name="setupWorkDays"]:checked').forEach(cb => {
                    workDays.push(cb.value);
                });

                const payload = {
                    wakeUpTime,
                    bedTime,
                    workStartTime,
                    workEndTime,
                    workDays
                };

                try {
                    await apiRequest('/auth/setup', 'POST', payload);
                    localStorage.setItem('bokea_setup_completed', 'true');
                    localStorage.setItem('bokea_wakeup_time', wakeUpTime);
                    localStorage.setItem('bokea_bed_time', bedTime);
                    localStorage.setItem('bokea_work_start', workStartTime);
                    localStorage.setItem('bokea_work_end', workEndTime);
                    localStorage.setItem('bokea_work_days', JSON.stringify(workDays));
                    
                    showToast("Profile set up completed!");
                    document.getElementById('setupScreen').classList.add('hidden');
                    await loadDashboardData();
                } catch (err) {
                    console.error("Setup failed", err);
                    showToast("Failed to complete setup", "error");
                }
            });
        }
    }

    function checkAuthToken() {
        const token = localStorage.getItem('bokea_auth_token');
        const savedName = localStorage.getItem('bokea_username');
        const setupCompleted = localStorage.getItem('bokea_setup_completed') === 'true';
        const appContainer = document.querySelector('.app-container');
        
        if (token && savedName && setupCompleted) {
            if (token === 'offline_mode_token') {
                isFallbackMode = true;
            }
            updateGreetings(savedName);
            welcomeScreen.classList.add('hidden');
            document.getElementById('setupScreen').classList.add('hidden');
            if (appContainer) appContainer.style.display = 'flex';
        } else {
            if (appContainer) appContainer.style.display = 'none';
            
            if (token && savedName) {
                welcomeScreen.classList.add('hidden');
                document.getElementById('setupScreen').classList.remove('hidden');
                initSetupPageListeners();
            } else {
                welcomeScreen.classList.remove('hidden');
                document.getElementById('setupScreen').classList.add('hidden');
            }
        }
    }

    // Skip Sign In (Offline Mode)
    const skipAuthBtn = document.getElementById('skipAuthBtn');
    if (skipAuthBtn) {
        skipAuthBtn.addEventListener('click', () => {
            localStorage.setItem('bokea_auth_token', 'offline_mode_token');
            localStorage.setItem('bokea_username', 'Guest');
            window.location.reload();
        });
    }

    // Brand click redirects to Home page
    const brandContainer = document.querySelector('.brand');
    if (brandContainer) {
        brandContainer.addEventListener('click', () => {
            const homeNavItem = document.querySelector('.nav-menu .nav-item[data-tab="home"]');
            if (homeNavItem) {
                homeNavItem.click();
            }
        });
    }

    // Toggle Forms
    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginFormSection.classList.add('hidden');
        registerFormSection.classList.remove('hidden');
        authErrorMsg.classList.add('hidden');
    });

    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        registerFormSection.classList.add('hidden');
        loginFormSection.classList.remove('hidden');
        authErrorMsg.classList.add('hidden');
    });

    // Login
    document.getElementById('loginBtn').addEventListener('click', async () => {
        const email = document.getElementById('loginEmailInput').value.trim();
        const password = document.getElementById('loginPasswordInput').value;
        if (!email || !password) {
            authErrorMsg.textContent = "Email and password are required";
            authErrorMsg.classList.remove('hidden');
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            authErrorMsg.textContent = "Please enter a valid email address (e.g. name@domain.com)";
            authErrorMsg.classList.remove('hidden');
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            if (res.ok) {
                const data = await res.json();
                localStorage.setItem('bokea_auth_token', data.token);
                localStorage.setItem('bokea_username', data.user.firstName);
                localStorage.setItem('bokea_setup_completed', data.user.isSetupCompleted ? 'true' : 'false');
                if (data.user.wakeUpTime) localStorage.setItem('bokea_wakeup_time', data.user.wakeUpTime);
                if (data.user.bedTime) localStorage.setItem('bokea_bed_time', data.user.bedTime);
                if (data.user.workStartTime) localStorage.setItem('bokea_work_start', data.user.workStartTime);
                if (data.user.workEndTime) localStorage.setItem('bokea_work_end', data.user.workEndTime);
                if (data.user.workDays) {
                    try {
                        localStorage.setItem('bokea_work_days', JSON.stringify(data.user.workDays.split(',')));
                    } catch(e) {
                        localStorage.setItem('bokea_work_days', '[]');
                    }
                }
                window.location.reload();
            } else {
                authErrorMsg.textContent = "Invalid email or password";
                authErrorMsg.classList.remove('hidden');
            }
        } catch (err) {
            authErrorMsg.textContent = "Network error";
            authErrorMsg.classList.remove('hidden');
        }
    });

    // Register
    document.getElementById('registerBtn').addEventListener('click', async () => {
        const firstName = document.getElementById('registerNameInput').value.trim();
        const email = document.getElementById('registerEmailInput').value.trim();
        const password = document.getElementById('registerPasswordInput').value;
        if (!email || !password || !firstName) {
            authErrorMsg.textContent = "All fields are required";
            authErrorMsg.classList.remove('hidden');
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            authErrorMsg.textContent = "Please enter a valid email address format (e.g. name@domain.com)";
            authErrorMsg.classList.remove('hidden');
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firstName, email, password })
            });

            if (res.ok) {
                const data = await res.json();
                localStorage.setItem('bokea_auth_token', data.token);
                localStorage.setItem('bokea_username', data.user.firstName);
                localStorage.setItem('bokea_setup_completed', data.user.isSetupCompleted ? 'true' : 'false');
                window.location.reload();
            } else {
                authErrorMsg.textContent = "Registration failed (email may be in use)";
                authErrorMsg.classList.remove('hidden');
            }
        } catch (err) {
            authErrorMsg.textContent = "Network error";
            authErrorMsg.classList.remove('hidden');
        }
    });

    window.logoutUser = function() {
        localStorage.removeItem('bokea_auth_token');
        localStorage.removeItem('bokea_username');
        localStorage.removeItem('bokea_setup_completed');
        localStorage.removeItem('bokea_wakeup_time');
        localStorage.removeItem('bokea_bed_time');
        localStorage.removeItem('bokea_work_start');
        localStorage.removeItem('bokea_work_end');
        localStorage.removeItem('bokea_work_days');
        
        // Immediately reset UI visibility to prevent showing default unstyled/previous state
        const welcomeScreen = document.getElementById('welcomeScreen');
        if (welcomeScreen) welcomeScreen.classList.remove('hidden');
        const setupScreen = document.getElementById('setupScreen');
        if (setupScreen) setupScreen.classList.add('hidden');
        
        // Clear input values
        const loginEmail = document.getElementById('loginEmailInput');
        const loginPass = document.getElementById('loginPasswordInput');
        const regName = document.getElementById('registerNameInput');
        const regEmail = document.getElementById('registerEmailInput');
        const regPass = document.getElementById('registerPasswordInput');
        if (loginEmail) loginEmail.value = '';
        if (loginPass) loginPass.value = '';
        if (regName) regName.value = '';
        if (regEmail) regEmail.value = '';
        if (regPass) regPass.value = '';

        window.location.reload();
    };

    checkAuthToken();

    // Profile Dropdown Toggle
    const profileAvatarBox = document.getElementById('profileAvatarBox');
    const dropdownMenuBox = document.getElementById('dropdownMenuBox');
    const notificationBellBox = document.getElementById('notificationBellBox');
    const notificationMenuBox = document.getElementById('notificationMenuBox');

    profileAvatarBox.addEventListener('click', (e) => {
        e.stopPropagation();
        notificationMenuBox.classList.remove('show');
        dropdownMenuBox.classList.toggle('show');
    });

    notificationBellBox.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenuBox.classList.remove('show');
        notificationMenuBox.classList.toggle('show');
    });

    window.addEventListener('click', () => {
        if (dropdownMenuBox.classList.contains('show')) {
            dropdownMenuBox.classList.remove('show');
        }
        if (notificationMenuBox.classList.contains('show')) {
            notificationMenuBox.classList.remove('show');
        }
    });

    document.getElementById('dropdownHomeBtn').addEventListener('click', (e) => {
        e.preventDefault();
        const homeNavItem = document.querySelector('.nav-menu .nav-item[data-tab="home"]');
        if (homeNavItem) {
            homeNavItem.click();
        }
        document.getElementById('dropdownMenuBox').classList.remove('show');
    });

    document.getElementById('dropdownSettingsBtn').addEventListener('click', (e) => {
        e.preventDefault();
        const settingsNavItem = document.querySelector('.nav-menu .nav-item[data-tab="settings"]');
        if (settingsNavItem) {
            settingsNavItem.click();
        }
        document.getElementById('dropdownMenuBox').classList.remove('show');
    });

    document.getElementById('dropdownSignOutBtn').addEventListener('click', (e) => {
        e.preventDefault();
        window.logoutUser();
    });

    // Notifications Clear All Action
    const clearNotificationsBtn = document.getElementById('clearNotificationsBtn');
    clearNotificationsBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const items = document.querySelectorAll('.notification-item');
        if (items.length === 0) return;
        
        // Trigger smooth slide out animation
        items.forEach(item => item.classList.add('clearing'));
        
        // Wait for CSS animation to finish (300ms)
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Snooze all Red and Amber tasks to green
        const warningTasks = tasks.filter(t => {
            const state = t.state || calculateTaskState(t);
            return state === 'Red' || state === 'Amber';
        });
        
        for (const task of warningTasks) {
            try {
                await apiRequest(`/tasks/${task.id}/snooze`, 'POST');
            } catch (err) {
                console.error("Failed to snooze task", task.id, err);
            }
        }
        
        await loadDashboardData();
        showToast("All notifications snoozed and cleared!");
    });

    // Dark Mode Toggle
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const themeToggleIcon = document.getElementById('themeToggleIcon');

    function setTheme(theme) {
        if (theme === 'dark') {
            document.body.classList.add('dark-theme');
            themeToggleIcon.setAttribute('data-lucide', 'sun');
            localStorage.setItem('bokea_theme', 'dark');
        } else {
            document.body.classList.remove('dark-theme');
            themeToggleIcon.setAttribute('data-lucide', 'moon');
            localStorage.setItem('bokea_theme', 'light');
        }
        updateThemeCardSelection(theme);
        refreshIcons();
    }

    themeToggleBtn.addEventListener('click', () => {
        document.body.classList.add('theme-transitioning');
        const isDark = document.body.classList.contains('dark-theme');
        setTheme(isDark ? 'light' : 'dark');
        setTimeout(() => {
            document.body.classList.remove('theme-transitioning');
        }, 500);
    });

    // Initial theme load
    const savedTheme = localStorage.getItem('bokea_theme');
    if (savedTheme === 'dark') {
        setTheme('dark');
    } else {
        setTheme('light');
    }

    // 1. Initialize offline database to ensure page runs even if server backend API is missing
    initLocalStorage();
    
    // 2. Load Dashboard values (only if logged in or using offline mode to prevent 401 reload loops)
    const token = localStorage.getItem('bokea_auth_token');
    const savedName = localStorage.getItem('bokea_username');
    if (token && savedName) {
        loadDashboardData();
    }
    
    // 3. Connect close button handlers
    const closeModalBtn = document.getElementById('closeModalBtn');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeModal);
    }
    const cancelModalBtn = document.getElementById('cancelModalBtn');
    if (cancelModalBtn) {
        cancelModalBtn.addEventListener('click', closeModal);
    }
    
    // Close modal on clicking outside content
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // 4. Attach event listeners for Sector Add Task buttons
    document.querySelectorAll('.addTaskBtn').forEach(btn => {
        btn.addEventListener('click', () => {
            const category = btn.getAttribute('data-category');
            openCreateTaskModal(category);
        });
    });
    
    // 5. Grid category state filtering buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeFilter = btn.getAttribute('data-filter');
            renderTaskGrid();
        });
    });
    
    // 6. Chart days toggles
    document.querySelectorAll('.toggle-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            chartRange = parseInt(btn.getAttribute('data-range')) || 7;
            
            // Re-render graph and stats rate
            renderAnalyticsGraph();
            renderStats();
        });
    });
    
    // Helper to debounce high-frequency events
    function debounce(func, delay) {
        let timeoutId;
        return function (...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    // 7. Window resize event to redraw responsive graph
    window.addEventListener('resize', debounce(() => {
        renderAnalyticsGraph();
    }, 150));
    
    // 8. Search input listener
    document.getElementById('taskSearchInput').addEventListener('input', () => {
        renderTaskGrid();
    });
    
    // 10. Sidebar Tab Navigation switcher
    document.querySelectorAll('.nav-menu .nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = item.getAttribute('data-tab');
            if (!tab) return;
            
            // Toggle active state
            document.querySelectorAll('.nav-menu .nav-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            
            // Hide all tab views and show current
            document.querySelectorAll('.tab-view').forEach(view => view.classList.add('hidden'));
            if (tab === 'home') {
                document.getElementById('homeView').classList.remove('hidden');
            } else if (tab === 'tasks') {
                document.getElementById('tasksView').classList.remove('hidden');
            } else if (tab === 'analytics') {
                document.getElementById('analyticsView').classList.remove('hidden');
                setTimeout(() => {
                    renderAnalyticsGraph();
                }, 50);
            } else if (tab === 'calendar') {
                document.getElementById('calendarFullView').classList.remove('hidden');
                if (!window.fullCalendarInitialized) {
                    initFullCalendar();
                    window.fullCalendarInitialized = true;
                }
            } else if (tab === 'settings') {
                document.getElementById('settingsView').classList.remove('hidden');
                loadSettingsIntoForm();
            }
        });
    });

    // 9. Set Current Date & Live Clock Display
    const dateOptions = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
    const currentDateEl = document.getElementById('currentDate');
    if (currentDateEl) {
        currentDateEl.textContent = new Date().toLocaleDateString('en-GB', dateOptions);
    }

    function updateLiveClock() {
        const timeElBig = document.getElementById('currentTimeBig');
        if (timeElBig) {
            const now = new Date();
            let hrs = now.getHours();
            const mins = String(now.getMinutes()).padStart(2, '0');
            const format = localStorage.getItem('bokea_clock_format') || '12h';
            if (format === '12h') {
                const ampm = hrs >= 12 ? 'PM' : 'AM';
                const displayH = hrs % 12 === 0 ? 12 : hrs % 12;
                timeElBig.textContent = `${displayH}:${mins} ${ampm}`;
            } else {
                timeElBig.textContent = `${String(hrs).padStart(2, '0')}:${mins}`;
            }
        }
    }
    updateLiveClock();
    setInterval(updateLiveClock, 1000);

    // 11. Settings View Loading, Theme and Saving Handler logic
    function loadSettingsIntoForm() {
        const nameInput = document.getElementById('settingsNameInput');
        const snoozeSelect = document.getElementById('settingsSnoozeSelect');
        const clockFormatSelect = document.getElementById('settingsClockFormat');
        const savedName = localStorage.getItem('bokea_username') || 'User';
        const savedSnooze = localStorage.getItem('bokea_default_snooze') || '24';
        const savedClockFormat = localStorage.getItem('bokea_clock_format') || '12h';
        const savedTheme = localStorage.getItem('bokea_theme') || 'light';

        if (nameInput) nameInput.value = savedName;
        if (snoozeSelect) snoozeSelect.value = savedSnooze;
        if (clockFormatSelect) clockFormatSelect.value = savedClockFormat;

        updateThemeCardSelection(savedTheme);

        // Load Schedule settings
        const settingsBedTime = document.getElementById('settingsBedTime');
        const settingsWakeUpTime = document.getElementById('settingsWakeUpTime');
        const settingsWorkStart = document.getElementById('settingsWorkStart');
        const settingsWorkEnd = document.getElementById('settingsWorkEnd');

        const savedBedTime = localStorage.getItem('bokea_bed_time') || '22:30';
        const savedWakeUpTime = localStorage.getItem('bokea_wakeup_time') || '06:30';
        const savedWorkStart = localStorage.getItem('bokea_work_start') || '09:00';
        const savedWorkEnd = localStorage.getItem('bokea_work_end') || '17:00';
        let savedWorkDays = [];
        try {
            savedWorkDays = JSON.parse(localStorage.getItem('bokea_work_days') || '["Monday","Tuesday","Wednesday","Thursday","Friday"]');
        } catch(e) {
            savedWorkDays = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
        }

        if (settingsBedTime) settingsBedTime.value = savedBedTime;
        if (settingsWakeUpTime) settingsWakeUpTime.value = savedWakeUpTime;
        if (settingsWorkStart) settingsWorkStart.value = savedWorkStart;
        if (settingsWorkEnd) settingsWorkEnd.value = savedWorkEnd;

        // Check the checkboxes for workdays
        document.querySelectorAll('input[name="settingsWorkDays"]').forEach(cb => {
            cb.checked = savedWorkDays.includes(cb.value);
        });

        // Setup settings page dynamic meter calculation
        if (settingsBedTime && settingsWakeUpTime) {
            const textEl = document.getElementById('settingsSleepDurationText');
            const labelEl = document.getElementById('settingsSleepHealthLabel');
            const barEl = document.getElementById('settingsSleepHealthBar');
            
            const triggerUpdate = () => {
                const duration = calculateSleepDuration(settingsBedTime.value, settingsWakeUpTime.value);
                if (textEl) textEl.textContent = `Sleep Duration: ${duration.toFixed(1)} hours`;
                if (labelEl && barEl) {
                    labelEl.className = 'health-badge';
                    barEl.className = 'meter-bar-fill';
                    if (duration >= 7 && duration <= 9) {
                        labelEl.textContent = 'Optimal';
                        labelEl.classList.add('health-optimal');
                        barEl.classList.add('health-optimal');
                        barEl.style.width = '100%';
                    } else if ((duration >= 6 && duration < 7) || (duration > 9 && duration <= 10)) {
                        labelEl.textContent = 'Marginal';
                        labelEl.classList.add('health-warning');
                        barEl.classList.add('health-warning');
                        barEl.style.width = '70%';
                    } else {
                        labelEl.textContent = 'Unhealthy';
                        labelEl.classList.add('health-danger');
                        barEl.classList.add('health-danger');
                        barEl.style.width = '40%';
                    }
                }
            };

            settingsBedTime.addEventListener('input', triggerUpdate);
            settingsWakeUpTime.addEventListener('input', triggerUpdate);
            triggerUpdate();
        }
    }

    function updateThemeCardSelection(theme) {
        const lightCard = document.getElementById('themeLightCard');
        const darkCard = document.getElementById('themeDarkCard');
        if (lightCard && darkCard) {
            lightCard.classList.remove('active');
            darkCard.classList.remove('active');
            if (theme === 'dark') {
                darkCard.classList.add('active');
            } else {
                lightCard.classList.add('active');
            }
        }
    }

    const appSettingsForm = document.getElementById('appSettingsForm');
    if (appSettingsForm) {
        appSettingsForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const nameInput = document.getElementById('settingsNameInput');
            const snoozeSelect = document.getElementById('settingsSnoozeSelect');
            
            if (nameInput) {
                const name = nameInput.value.trim();
                if (name) {
                    localStorage.setItem('bokea_username', name);
                    updateGreetings(name);
                }
            }

            if (snoozeSelect) {
                localStorage.setItem('bokea_default_snooze', snoozeSelect.value);
            }

            const darkCard = document.getElementById('themeDarkCard');
            const theme = (darkCard && darkCard.classList.contains('active')) ? 'dark' : 'light';
            setTheme(theme);

            // Save Schedule to API
            const token = localStorage.getItem('bokea_auth_token');
            const bedTime = document.getElementById('settingsBedTime').value;
            const wakeUpTime = document.getElementById('settingsWakeUpTime').value;
            const workStartTime = document.getElementById('settingsWorkStart').value;
            const workEndTime = document.getElementById('settingsWorkEnd').value;
            
            const workDays = [];
            document.querySelectorAll('input[name="settingsWorkDays"]:checked').forEach(cb => {
                workDays.push(cb.value);
            });

            if (token && token !== 'offline_mode_token') {
                try {
                    await apiRequest('/auth/profile', 'PUT', {
                        wakeUpTime,
                        bedTime,
                        workStartTime,
                        workEndTime,
                        workDays
                    });
                } catch(err) {
                    console.error("Failed to save profile schedule settings to server.", err);
                }
            }

            localStorage.setItem('bokea_wakeup_time', wakeUpTime);
            localStorage.setItem('bokea_bed_time', bedTime);
            localStorage.setItem('bokea_work_start', workStartTime);
            localStorage.setItem('bokea_work_end', workEndTime);
            localStorage.setItem('bokea_work_days', JSON.stringify(workDays));

            const clockFormatSelect = document.getElementById('settingsClockFormat');
            if (clockFormatSelect) {
                localStorage.setItem('bokea_clock_format', clockFormatSelect.value);
            }

            showToast("Settings saved successfully!");
            updateLiveClock();
            renderDailyScheduleTimeline();
        });
    }

    const lightCard = document.getElementById('themeLightCard');
    const darkCard = document.getElementById('themeDarkCard');
    if (lightCard && darkCard) {
        lightCard.addEventListener('click', () => {
            setTheme('light');
        });
        darkCard.addEventListener('click', () => {
            setTheme('dark');
        });
    }

    const resetDataBtn = document.getElementById('settingsResetDataBtn');
    if (resetDataBtn) {
        resetDataBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to reset all data? This will clear all custom tasks and history, resetting to default seeded tasks.")) {
                localStorage.removeItem(STORAGE_KEYS.TASKS);
                localStorage.removeItem(STORAGE_KEYS.HISTORY);
                localStorage.removeItem('bokea_username');
                
                welcomeScreen.classList.remove('hidden');
                checkUserName();
                
                const nameInput = document.getElementById('settingsNameInput');
                if (nameInput) nameInput.value = '';
                
                const homeNavItem = document.querySelector('.nav-menu .nav-item[data-tab="home"]');
                if (homeNavItem) homeNavItem.click();
                
                loadDashboardData();
                showToast("Application data reset successfully.", "warning");
            }
        });
    }

});

// Expose click action handlers to the window object so dynamic templates can invoke them
window.completeTask = completeTask;
window.snoozeTask = snoozeTask;
window.deleteTask = deleteTask;
window.openEditTaskModal = openEditTaskModal;
window.openCreateTaskModal = openCreateTaskModal;

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(registration => {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      })
      .catch(err => {
        console.error('ServiceWorker registration failed: ', err);
      });
  });
}

// --- Schedule Timeline Rendering Helper ---
function renderDailyScheduleTimeline() {
    const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const todayName = weekdays[new Date().getDay()];

    const barContainer = document.getElementById('timelineBar');
    const legend = document.getElementById('timelineLegend');
    if (!barContainer || !legend) return;

    // Load schedule preferences
    const bedTime = localStorage.getItem('bokea_bed_time') || '22:30';
    const wakeUpTime = localStorage.getItem('bokea_wakeup_time') || '06:30';
    const workStart = localStorage.getItem('bokea_work_start') || '09:00';
    const workEnd = localStorage.getItem('bokea_work_end') || '17:00';
    
    let workDays = [];
    try {
        workDays = JSON.parse(localStorage.getItem('bokea_work_days') || '["Monday","Tuesday","Wednesday","Thursday","Friday"]');
    } catch(e) {
        workDays = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
    }

    const isWorkday = workDays.includes(todayName);
    
    function parseTimeToMinutes(t) {
        if (!t) return 0;
        const [h, m] = t.split(':').map(Number);
        return h * 60 + m;
    }
    
    const wakeMin = parseTimeToMinutes(wakeUpTime);
    const bedMin = parseTimeToMinutes(bedTime);
    const workStartMin = parseTimeToMinutes(workStart);
    const workEndMin = parseTimeToMinutes(workEnd);
    
    // Fill 1440 minutes (0 = Free, 1 = Sleep, 2 = Work)
    const minutes = new Array(1440).fill(0);
    
    // Fill Sleep
    if (bedMin > wakeMin) {
        for (let i = bedMin; i < 1440; i++) minutes[i] = 1;
        for (let i = 0; i < wakeMin; i++) minutes[i] = 1;
    } else {
        for (let i = bedMin; i < wakeMin; i++) minutes[i] = 1;
    }
    
    // Fill Work (overwrites Free, not Sleep)
    if (isWorkday) {
        if (workEndMin > workStartMin) {
            for (let i = workStartMin; i < workEndMin; i++) {
                if (minutes[i] === 0) minutes[i] = 2;
            }
        } else {
            for (let i = workStartMin; i < 1440; i++) {
                if (minutes[i] === 0) minutes[i] = 2;
            }
            for (let i = 0; i < workEndMin; i++) {
                if (minutes[i] === 0) minutes[i] = 2;
            }
        }
    }
    
    // Calculate Life Admin minutes from active predefined/custom tasks
    const todayStr = new Date().toISOString().split('T')[0];
    let lifeAdminMinsNeeded = 0;
    
    tasks.forEach(t => {
        const nameLower = t.name.toLowerCase().trim();
        if (nameLower === 'brush teeth' || nameLower === 'shower' || nameLower === 'clean teeth' || nameLower === 'wash face' || t.durationMinutes) {
            let dur = 0;
            if (nameLower === 'brush teeth') dur = 5;
            else if (nameLower === 'shower') dur = 15;
            else if (nameLower === 'clean teeth') dur = 5;
            else if (nameLower === 'wash face') dur = 3;
            else dur = parseInt(t.durationMinutes) || 0;
            
            lifeAdminMinsNeeded += dur;
        }
    });

    // Fill Life Admin (overwrites Free Time, i.e. state = 0)
    let filledAdmin = 0;
    for (let i = 0; i < 1440; i++) {
        if (filledAdmin >= lifeAdminMinsNeeded) break;
        if (minutes[i] === 0) {
            minutes[i] = 3;
            filledAdmin++;
        }
    }
    
    // Group minutes into blocks
    const segments = [];
    let currentState = minutes[0];
    let startMin = 0;
    
    for (let i = 1; i <= 1440; i++) {
        if (i === 1440 || minutes[i] !== currentState) {
            segments.push({
                state: currentState,
                start: startMin,
                end: i,
                duration: (i - startMin) / 60
            });
            if (i < 1440) {
                currentState = minutes[i];
                startMin = i;
            }
        }
    }

    // Format minutes to HH:MM based on clock preference
    function formatMinutes(min) {
        const h = Math.floor(min / 60) % 24;
        const m = min % 60;
        const format = localStorage.getItem('bokea_clock_format') || '12h';
        if (format === '12h') {
            const ampm = h >= 12 ? 'PM' : 'AM';
            const displayH = h % 12 === 0 ? 12 : h % 12;
            return `${displayH}:${String(m).padStart(2, '0')} ${ampm}`;
                } else {
            return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }
    }

    // Map segments to HTML
    let barHtml = '';
    let sleepTotal = 0;
    let workTotal = 0;
    let freeTotal = 0;
    let lifeAdminTotal = 0;

    segments.forEach(seg => {
        let stateClass = 'segment-free';
        let stateName = 'Free Time';
        if (seg.state === 1) {
            stateClass = 'segment-sleep';
            stateName = 'Sleep';
            sleepTotal += seg.duration;
        } else if (seg.state === 2) {
            stateClass = 'segment-work';
            stateName = 'Work';
            workTotal += seg.duration;
        } else if (seg.state === 3) {
            stateClass = 'segment-life-admin';
            stateName = 'Life Admin';
            lifeAdminTotal += seg.duration;
        } else {
            freeTotal += seg.duration;
        }

        const widthPct = (seg.duration / 24) * 100;
        const timeTooltip = `${stateName}: ${formatMinutes(seg.start)} - ${formatMinutes(seg.end)} (${seg.duration.toFixed(1)} hrs)`;
        
        barHtml += `
            <div class="timeline-segment ${stateClass}" 
                 style="width: ${widthPct}%;" 
                 title="${timeTooltip}">
            </div>
        `;
    });
    
    barContainer.innerHTML = barHtml;

    // Render legend
    const legendData = [
        { name: 'Sleep', hours: sleepTotal, color: 'var(--color-timeline-sleep)' },
        { name: 'Work', hours: workTotal, color: 'var(--color-timeline-work)' },
        { name: 'Life Admin', hours: lifeAdminTotal, color: 'var(--color-timeline-life-admin)' },
        { name: 'Free Time', hours: freeTotal, color: 'var(--color-timeline-free)' }
    ];

    let legendHtml = '';
    legendData.forEach(item => {
        const pct = (item.hours / 24) * 100;
        legendHtml += `
            <div style="display: flex; align-items: center; gap: 8px; justify-content: center; padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border-color); background: rgba(0,0,0,0.015);">
                <span style="width: 8px; height: 8px; border-radius: 50%; background: ${item.color}; border: 1px solid var(--border-color);"></span>
                <div style="display: flex; flex-direction: column; align-items: flex-start; gap: 1px;">
                    <span style="font-size: 0.72rem; font-weight: 600; color: var(--text-main);">${item.name}</span>
                    <span style="font-size: 0.65rem; color: var(--text-secondary);">${item.hours.toFixed(1)}h (${pct.toFixed(0)}%)</span>
                </div>
            </div>
        `;
    });
    legend.innerHTML = legendHtml;

    // Update timeline markers based on clock format
    const markersEl = document.getElementById('timelineMarkers');
    if (markersEl) {
        const format = localStorage.getItem('bokea_clock_format') || '12h';
        if (format === '12h') {
            markersEl.innerHTML = `
                <span>12 AM</span>
                <span>6 AM</span>
                <span>12 PM</span>
                <span>6 PM</span>
                <span>12 AM</span>
            `;
        } else {
            markersEl.innerHTML = `
                <span>00:00</span>
                <span>06:00</span>
                <span>12:00</span>
                <span>18:00</span>
                <span>00:00</span>
            `;
        }
    }

    // Update Day Badge
    const badge = document.getElementById('scheduleDayBadge');
    if (badge) {
        badge.textContent = 'Today';
    }
}

// Expose renderDailyScheduleTimeline to the window object
window.renderDailyScheduleTimeline = renderDailyScheduleTimeline;

// --- Full Page Calendar Logic ---
let fullCalendarViewDate = new Date();

function initFullCalendar() {
    renderFullPageCalendar();
    
    const prevBtn = document.getElementById('calendarPrevMonthBtn');
    const nextBtn = document.getElementById('calendarNextMonthBtn');
    
    if (prevBtn && !prevBtn.dataset.listenerAttached) {
        prevBtn.addEventListener('click', () => {
            fullCalendarViewDate.setMonth(fullCalendarViewDate.getMonth() - 1);
            renderFullPageCalendar();
        });
        prevBtn.dataset.listenerAttached = 'true';
    }
    
    if (nextBtn && !nextBtn.dataset.listenerAttached) {
        nextBtn.addEventListener('click', () => {
            fullCalendarViewDate.setMonth(fullCalendarViewDate.getMonth() + 1);
            renderFullPageCalendar();
        });
        nextBtn.dataset.listenerAttached = 'true';
    }
}

function createDayCell(year, month, day, isOtherMonth) {
    const cell = document.createElement('div');
    cell.className = 'full-calendar-day';
    if (isOtherMonth) {
        cell.classList.add('other-month');
    }
    
    const now = new Date();
    if (!isOtherMonth && year === now.getFullYear() && month === now.getMonth() && day === now.getDate()) {
        cell.classList.add('today');
    }
    
    const daySpan = document.createElement('span');
    daySpan.className = 'day-number';
    daySpan.textContent = day;
    cell.appendChild(daySpan);
    
    // Format date string for task matching (YYYY-MM-DD)
    const cellDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    
    // Look up and sync fixed tasks matching this date
    if (Array.isArray(tasks)) {
        const matchingTasks = tasks.filter(t => {
            const mapped = mapBackendTask(t);
            return mapped.type === 'fixed' && mapped.dueDate === cellDateStr;
        });
        
        if (matchingTasks.length > 0) {
            const tasksContainer = document.createElement('div');
            tasksContainer.className = 'full-calendar-tasks';
            
            matchingTasks.forEach(t => {
                const badge = document.createElement('div');
                badge.className = `full-calendar-task-badge state-${calculateTaskState(t).toLowerCase()}`;
                badge.textContent = t.name;
                badge.title = t.name;
                tasksContainer.appendChild(badge);
            });
            
            cell.appendChild(tasksContainer);
        }
    }
    
    return cell;
}

function renderFullPageCalendar() {
    const titleEl = document.getElementById('calendarFullViewTitle');
    const gridEl = document.getElementById('calendarFullViewGrid');
    if (!titleEl || !gridEl) return;
    
    const year = fullCalendarViewDate.getFullYear();
    const month = fullCalendarViewDate.getMonth();
    
    // Update Month/Year Header Title
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    titleEl.textContent = `${monthNames[month]} ${year}`;
    
    gridEl.innerHTML = '';
    
    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();
    const prevMonthTotalDays = new Date(year, month, 0).getDate();
    
    // Render previous month padding days
    const prevMonth = month === 0 ? 11 : month - 1;
    const prevYear = month === 0 ? year - 1 : year;
    for (let i = firstDayIndex - 1; i >= 0; i--) {
        const day = prevMonthTotalDays - i;
        gridEl.appendChild(createDayCell(prevYear, prevMonth, day, true));
    }
    
    // Render current month days
    for (let day = 1; day <= totalDays; day++) {
        gridEl.appendChild(createDayCell(year, month, day, false));
    }
    
    // Render next month padding days (up to 42 cells)
    const nextMonth = month === 11 ? 0 : month + 1;
    const nextYear = month === 11 ? year + 1 : year;
    const totalCellsRendered = firstDayIndex + totalDays;
    const remainingCells = 42 - totalCellsRendered;
    for (let day = 1; day <= remainingCells; day++) {
        gridEl.appendChild(createDayCell(nextYear, nextMonth, day, true));
    }
    
    refreshIcons();
}

