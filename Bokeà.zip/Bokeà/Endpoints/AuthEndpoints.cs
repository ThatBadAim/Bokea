using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Bokea.Database;

namespace Bokea.Endpoints
{
    public static class AuthEndpoints
    {
        public static void MapAuthEndpoints(this IEndpointRouteBuilder app)
        {
            var group = app.MapGroup("/api/auth");

            group.MapPost("/register", async (RegisterRequest req, AppDbContext db, IConfiguration config) =>
            {
                if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Password) || string.IsNullOrWhiteSpace(req.FirstName))
                {
                    return Results.BadRequest("All fields are required.");
                }

                var emailNormalized = req.Email.Trim().ToLowerInvariant();

                if (!System.Text.RegularExpressions.Regex.IsMatch(emailNormalized, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
                {
                    return Results.BadRequest("Invalid email address format.");
                }

                if (await db.Users.AnyAsync(u => u.Email == emailNormalized))
                {
                    return Results.BadRequest("Email is already registered.");
                }

                var user = new User
                {
                    Email = emailNormalized,
                    FirstName = req.FirstName,
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password),
                    IsSetupCompleted = false
                };

                db.Users.Add(user);
                await db.SaveChangesAsync();

                var jwtKey = config["Jwt:Key"] ?? "SuperSecretBokeaKeyThatNeedsToBeLongEnoughForHS256!!!123456";
                var token = GenerateJwtToken(user, jwtKey);
                return Results.Ok(new { 
                    Token = token, 
                    User = new { 
                        user.Id, 
                        user.FirstName, 
                        user.Email,
                        user.IsSetupCompleted,
                        user.WakeUpTime,
                        user.BedTime,
                        user.WorkStartTime,
                        user.WorkEndTime,
                        user.WorkDays
                    } 
                });
            });

            group.MapPost("/login", async (LoginRequest req, AppDbContext db, IConfiguration config) =>
            {
                var emailNormalized = (req.Email ?? "").Trim().ToLowerInvariant();
                var user = await db.Users.SingleOrDefaultAsync(u => u.Email == emailNormalized);

                if (user == null || !BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash))
                {
                    return Results.Unauthorized();
                }

                var jwtKey = config["Jwt:Key"] ?? "SuperSecretBokeaKeyThatNeedsToBeLongEnoughForHS256!!!123456";
                var token = GenerateJwtToken(user, jwtKey);
                return Results.Ok(new { 
                    Token = token, 
                    User = new { 
                        user.Id, 
                        user.FirstName, 
                        user.Email,
                        user.IsSetupCompleted,
                        user.WakeUpTime,
                        user.BedTime,
                        user.WorkStartTime,
                        user.WorkEndTime,
                        user.WorkDays
                    } 
                });
            });

            // POST /api/auth/setup - Save setup settings
            group.MapPost("/setup", async (SetupRequest req, AppDbContext db, ClaimsPrincipal userClaim) =>
            {
                int userId = int.Parse(userClaim.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
                var user = await db.Users.FindAsync(userId);
                if (user == null)
                {
                    return Results.NotFound("User not found.");
                }

                user.WakeUpTime = req.WakeUpTime;
                user.BedTime = req.BedTime;
                user.WorkStartTime = req.WorkStartTime;
                user.WorkEndTime = req.WorkEndTime;
                user.WorkDays = req.WorkDays != null ? string.Join(",", req.WorkDays) : null;
                user.IsSetupCompleted = true;

                await db.SaveChangesAsync();
                return Results.Ok(new { 
                    user.Id, 
                    user.FirstName, 
                    user.Email,
                    user.IsSetupCompleted,
                    user.WakeUpTime,
                    user.BedTime,
                    user.WorkStartTime,
                    user.WorkEndTime,
                    user.WorkDays
                });
            }).RequireAuthorization();

            // GET /api/auth/profile - Get current user profile & setup settings
            group.MapGet("/profile", async (AppDbContext db, ClaimsPrincipal userClaim) =>
            {
                int userId = int.Parse(userClaim.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
                var user = await db.Users.FindAsync(userId);
                if (user == null)
                {
                    return Results.NotFound("User not found.");
                }

                return Results.Ok(new { 
                    user.Id, 
                    user.FirstName, 
                    user.Email,
                    user.IsSetupCompleted,
                    user.WakeUpTime,
                    user.BedTime,
                    user.WorkStartTime,
                    user.WorkEndTime,
                    workDays = user.WorkDays != null ? user.WorkDays.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList() : new System.Collections.Generic.List<string>()
                });
            }).RequireAuthorization();

            // PUT /api/auth/profile - Update user profile & settings
            group.MapPut("/profile", async (SetupRequest req, AppDbContext db, ClaimsPrincipal userClaim) =>
            {
                int userId = int.Parse(userClaim.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
                var user = await db.Users.FindAsync(userId);
                if (user == null)
                {
                    return Results.NotFound("User not found.");
                }

                user.WakeUpTime = req.WakeUpTime;
                user.BedTime = req.BedTime;
                user.WorkStartTime = req.WorkStartTime;
                user.WorkEndTime = req.WorkEndTime;
                user.WorkDays = req.WorkDays != null ? string.Join(",", req.WorkDays) : null;

                await db.SaveChangesAsync();
                return Results.Ok(new { 
                    user.Id, 
                    user.FirstName, 
                    user.Email,
                    user.IsSetupCompleted,
                    user.WakeUpTime,
                    user.BedTime,
                    user.WorkStartTime,
                    user.WorkEndTime,
                    user.WorkDays
                });
            }).RequireAuthorization();
        }

        private static string GenerateJwtToken(User user, string jwtKey)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim("FirstName", user.FirstName),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddDays(7),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }

    public class RegisterRequest
    {
        public string Email { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class LoginRequest
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class SetupRequest
    {
        public string WakeUpTime { get; set; } = string.Empty;
        public string BedTime { get; set; } = string.Empty;
        public string WorkStartTime { get; set; } = string.Empty;
        public string WorkEndTime { get; set; } = string.Empty;
        public System.Collections.Generic.List<string> WorkDays { get; set; } = new();
    }
}
