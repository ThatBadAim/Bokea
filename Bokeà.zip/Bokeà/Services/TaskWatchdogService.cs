using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Bokea.Database;

namespace Bokea.Services;

public class TaskWatchdogService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<TaskWatchdogService> _logger;

    public TaskWatchdogService(IServiceScopeFactory scopeFactory, ILogger<TaskWatchdogService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("TaskWatchdogService started.");

        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(30));

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RecalculateTaskStatesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during task state recalculation.");
            }

            try
            {
                await timer.WaitForNextTickAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        _logger.LogInformation("TaskWatchdogService stopped.");
    }

    private async Task RecalculateTaskStatesAsync(CancellationToken stoppingToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var tasks = await dbContext.Tasks.ToListAsync(stoppingToken);
        var currentTime = DateTime.UtcNow;
        bool hasChanges = false;

        foreach (var task in tasks)
        {
            var newState = CalculateState(task, currentTime);
            if (task.State != newState)
            {
                _logger.LogInformation("Updating Task {TaskId} ('{Title}') state from {OldState} to {NewState}.", 
                    task.Id, task.Title, task.State, newState);
                task.State = newState;
                hasChanges = true;
            }
        }

        if (hasChanges)
        {
            await dbContext.SaveChangesAsync(stoppingToken);
        }
    }

    public static TaskState CalculateState(TaskItem task, DateTime currentTime)
    {
        // Snooze override:
        // If SnoozedUntil is set and CurrentTime < SnoozedUntil, the state should be forced/overridden to Green.
        if (task.SnoozedUntil.HasValue && currentTime < task.SnoozedUntil.Value)
        {
            return TaskState.Green;
        }

        if (task.IntervalType == IntervalType.IntervalBased)
        {
            var anchorDate = task.LastCompletedAt ?? task.CreatedAt;
            var elapsedTime = currentTime - anchorDate;
            
            if (!task.IntervalDays.HasValue || task.IntervalDays.Value <= 0)
            {
                return TaskState.Green;
            }

            var ratio = elapsedTime.TotalDays / task.IntervalDays.Value;
            
            if (ratio < 0.8)
            {
                return TaskState.Green;
            }
            else if (ratio < 1.0)
            {
                return TaskState.Amber;
            }
            else
            {
                return TaskState.Red;
            }
        }
        else // FixedDate
        {
            if (!task.DueDate.HasValue)
            {
                return TaskState.Green;
            }

            var remainingTime = task.DueDate.Value - currentTime;
            
            if (remainingTime.TotalDays > 1)
            {
                return TaskState.Green;
            }
            else if (remainingTime.TotalDays >= 0)
            {
                return TaskState.Amber;
            }
            else
            {
                return TaskState.Red;
            }
        }
    }
}
