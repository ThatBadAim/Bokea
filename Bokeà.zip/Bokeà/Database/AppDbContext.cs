using Microsoft.EntityFrameworkCore;
using System;

namespace Bokea.Database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
        {
        }

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<TaskItem> Tasks { get; set; } = null!;
        public DbSet<TaskCompletionLog> TaskCompletionLogs { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Default connection string if not configured via DI (e.g. during migrations/tests or local run)
                optionsBuilder.UseSqlite("Data Source=Bokea.db");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure enums as strings in SQLite
            modelBuilder.Entity<TaskItem>()
                .Property(t => t.Sector)
                .HasConversion<string>();

            modelBuilder.Entity<TaskItem>()
                .Property(t => t.IntervalType)
                .HasConversion<string>();

            modelBuilder.Entity<TaskItem>()
                .Property(t => t.State)
                .HasConversion<string>();

            // Configure DueDate converter
            modelBuilder.Entity<TaskItem>()
                .Property(t => t.DueDate)
                .HasConversion(
                    v => v.HasValue ? (DateTime?)v.Value : null,
                    v => v.HasValue ? new DueDateType(v.Value) : DueDateType.Null
                );

            // Configure User-Task relationship
            modelBuilder.Entity<TaskItem>()
                .HasOne(t => t.User)
                .WithMany(u => u.Tasks)
                .HasForeignKey(t => t.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure Database Indexes
            modelBuilder.Entity<TaskItem>().HasIndex(t => t.UserId);
            modelBuilder.Entity<TaskItem>().HasIndex(t => t.State);
            modelBuilder.Entity<TaskItem>().HasIndex(t => t.Sector);
            modelBuilder.Entity<TaskCompletionLog>().HasIndex(l => l.TaskId);
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            // Seed Test User
            // Note: PasswordHash is just "password" hashed for demonstration, normally this would be a proper hash.
            // But since this is a simple dashboard, we can just hash it in the AuthEndpoints. For seeding, let's use a dummy hash or leave it plain for testing if Auth logic allows it. Let's use a dummy hash for now, but in AuthEndpoints we'll use BCrypt or ASP.NET Core Identity's hasher. We will just use a known SHA256 or something simple for the test user. Let's use BCrypt equivalent or plain for now.
            // Let's just create a test user.
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Email = "test@example.com",
                    FirstName = "Test User",
                    PasswordHash = "$2a$11$qjsKcdN69yiK.YZClfFq6u9ntAZZxNkFhNtDKd1D8vNi3nRhC/NgS", // Hashed password "password"
                    CreatedAt = new DateTime(2026, 6, 1, 0, 0, 0, DateTimeKind.Utc)
                }
            );

            // Seed TaskItems
            modelBuilder.Entity<TaskItem>().HasData(
                // Health & Vitality
                new TaskItem
                {
                    Id = 1,
                    UserId = 1,
                    Title = "Morning Cardio",
                    Description = "30-minute morning jog or exercise routine.",
                    Sector = Sector.HealthAndVitality,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 1,
                    DueDate = new DateTime(2026, 6, 9, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 6, 8, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 6, 3, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Green
                },
                new TaskItem
                {
                    Id = 2,
                    UserId = 1,
                    Title = "Annual Physical Checkup",
                    Description = "Yearly health checkup with primary care physician.",
                    Sector = Sector.HealthAndVitality,
                    IntervalType = IntervalType.FixedDate,
                    DueDate = new DateTime(2026, 4, 8, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2025, 6, 8, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Red
                },
                new TaskItem
                {
                    Id = 3,
                    UserId = 1,
                    Title = "Dental Clean-up",
                    Description = "Bi-annual dental checkup and clean-up.",
                    Sector = Sector.HealthAndVitality,
                    IntervalType = IntervalType.FixedDate,
                    DueDate = new DateTime(2026, 6, 9, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2025, 12, 8, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Amber
                },

                // Career & Finance
                new TaskItem
                {
                    Id = 4,
                    UserId = 1,
                    Title = "Weekly Budget Review",
                    Description = "Review personal finances and expenses from the past week.",
                    Sector = Sector.CareerAndFinance,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 7,
                    DueDate = new DateTime(2026, 6, 5, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 5, 29, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 5, 9, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Red
                },
                new TaskItem
                {
                    Id = 5,
                    UserId = 1,
                    Title = "Submit Monthly Expense Report",
                    Description = "Prepare and submit business expenses for reimbursement.",
                    Sector = Sector.CareerAndFinance,
                    IntervalType = IntervalType.FixedDate,
                    DueDate = new DateTime(2026, 6, 9, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 5, 9, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 5, 25, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Amber
                },
                new TaskItem
                {
                    Id = 6,
                    UserId = 1,
                    Title = "Update Resume",
                    Description = "Add new projects and skills to the professional resume.",
                    Sector = Sector.CareerAndFinance,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 180,
                    DueDate = new DateTime(2026, 9, 8, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 3, 12, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 3, 12, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Green
                },

                // Relationships & Social
                new TaskItem
                {
                    Id = 7,
                    UserId = 1,
                    Title = "Call Parents",
                    Description = "Catch up with parents on the phone.",
                    Sector = Sector.RelationshipsAndSocial,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 7,
                    DueDate = new DateTime(2026, 6, 8, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 6, 1, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 4, 8, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Amber
                },
                new TaskItem
                {
                    Id = 8,
                    UserId = 1,
                    Title = "Plan Date Night",
                    Description = "Organize a special evening out with partner.",
                    Sector = Sector.RelationshipsAndSocial,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 14,
                    DueDate = new DateTime(2026, 6, 3, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 5, 20, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 5, 8, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Red
                },
                new TaskItem
                {
                    Id = 9,
                    UserId = 1,
                    Title = "Friend's Birthday Gift",
                    Description = "Select and order a gift for birthday party.",
                    Sector = Sector.RelationshipsAndSocial,
                    IntervalType = IntervalType.FixedDate,
                    DueDate = new DateTime(2026, 6, 18, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 6, 3, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Green
                },

                // Mind & Environment
                new TaskItem
                {
                    Id = 10,
                    UserId = 1,
                    Title = "Read 10 Pages",
                    Description = "Daily reading of non-fiction book.",
                    Sector = Sector.MindAndEnvironment,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 1,
                    DueDate = new DateTime(2026, 6, 9, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 6, 8, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 5, 29, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Green
                },
                new TaskItem
                {
                    Id = 11,
                    UserId = 1,
                    Title = "Deep Clean Apartment",
                    Description = "Monthly deep cleaning of bedroom, kitchen, and bathroom.",
                    Sector = Sector.MindAndEnvironment,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 30,
                    DueDate = new DateTime(2026, 6, 6, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 5, 7, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 4, 8, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Red
                },
                new TaskItem
                {
                    Id = 12,
                    UserId = 1,
                    Title = "Meditation Session",
                    Description = "Daily mindfulness meditation practice.",
                    Sector = Sector.MindAndEnvironment,
                    IntervalType = IntervalType.IntervalBased,
                    IntervalDays = 1,
                    DueDate = new DateTime(2026, 6, 8, 0, 0, 0, DateTimeKind.Utc),
                    LastCompletedAt = new DateTime(2026, 6, 7, 0, 0, 0, DateTimeKind.Utc),
                    CreatedAt = new DateTime(2026, 6, 3, 0, 0, 0, DateTimeKind.Utc),
                    State = TaskState.Amber
                }
            );

            // Seed TaskCompletionLogs
            modelBuilder.Entity<TaskCompletionLog>().HasData(
                new TaskCompletionLog { Id = 1, TaskId = 1, CompletedAt = new DateTime(2026, 6, 8, 8, 30, 0, DateTimeKind.Utc), Notes = "30 mins run on treadmill." },
                new TaskCompletionLog { Id = 2, TaskId = 4, CompletedAt = new DateTime(2026, 5, 29, 18, 0, 0, DateTimeKind.Utc), Notes = "Budget reviewed, spending was high on dining out." },
                new TaskCompletionLog { Id = 3, TaskId = 6, CompletedAt = new DateTime(2026, 3, 12, 14, 0, 0, DateTimeKind.Utc), Notes = "Added latest project accomplishments." },
                new TaskCompletionLog { Id = 4, TaskId = 7, CompletedAt = new DateTime(2026, 6, 1, 19, 15, 0, DateTimeKind.Utc), Notes = "Had a nice chat on Sunday." },
                new TaskCompletionLog { Id = 5, TaskId = 8, CompletedAt = new DateTime(2026, 5, 20, 20, 0, 0, DateTimeKind.Utc), Notes = "Dinner at Italian restaurant." },
                new TaskCompletionLog { Id = 6, TaskId = 10, CompletedAt = new DateTime(2026, 6, 8, 22, 0, 0, DateTimeKind.Utc), Notes = "Finished chapter 4 of design patterns book." },
                new TaskCompletionLog { Id = 7, TaskId = 11, CompletedAt = new DateTime(2026, 5, 7, 11, 0, 0, DateTimeKind.Utc), Notes = "Cleaned kitchen and living room." },
                new TaskCompletionLog { Id = 8, TaskId = 12, CompletedAt = new DateTime(2026, 6, 7, 7, 45, 0, DateTimeKind.Utc), Notes = "15 min mindfulness practice." }
            );
        }
    }

    public static class DbInitializer
    {
        public static void Initialize(AppDbContext context)
        {
            context.Database.EnsureCreated();
        }
    }
}
