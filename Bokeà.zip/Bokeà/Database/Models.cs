using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Bokea.Database
{
    public enum Sector
    {
        HealthAndVitality,
        CareerAndFinance,
        RelationshipsAndSocial,
        MindAndEnvironment
    }

    public enum IntervalType
    {
        IntervalBased,
        FixedDate
    }

    public enum TaskState
    {
        Green,
        Amber,
        Red
    }

    public class DueDateType
    {
        public DateTime Value { get; }
        public bool HasValue { get; }

        public DueDateType(DateTime value)
        {
            Value = value;
            HasValue = true;
        }

        private DueDateType()
        {
            HasValue = false;
        }

        public static readonly DueDateType Null = new DueDateType();

        public static implicit operator DueDateType(DateTime dt) => new DueDateType(dt);
        public static implicit operator DateTime(DueDateType d) => d.HasValue ? d.Value : throw new InvalidOperationException("Nullable object must have a value.");

        public static TimeSpan operator -(DueDateType left, DateTime right)
        {
            if (left == null || !left.HasValue) return TimeSpan.Zero;
            return left.Value - right;
        }

        public static bool operator ==(DueDateType? left, object? right)
        {
            if (right is null)
            {
                return left is null || !left.HasValue;
            }
            if (left is null) return false;
            return left.Equals(right);
        }

        public static bool operator !=(DueDateType? left, object? right)
        {
            return !(left == right);
        }

        public override bool Equals(object? obj)
        {
            if (obj is DueDateType other)
            {
                if (!HasValue && !other.HasValue) return true;
                if (HasValue && other.HasValue) return Value.Equals(other.Value);
                return false;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HasValue ? Value.GetHashCode() : 0;
        }

        public override string ToString()
        {
            return HasValue ? Value.ToString() : string.Empty;
        }

        public string ToString(string format)
        {
            return HasValue ? Value.ToString(format) : string.Empty;
        }
    }

    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Wake up & Sleep Times
        public string? WakeUpTime { get; set; }
        public string? BedTime { get; set; }

        // Work Schedule Details
        public string? WorkStartTime { get; set; }
        public string? WorkEndTime { get; set; }
        public string? WorkDays { get; set; } // Comma-separated list of weekdays (e.g. "Monday,Tuesday")

        public bool IsSetupCompleted { get; set; } = false;

        // Navigation property
        public ICollection<TaskItem> Tasks { get; set; } = new List<TaskItem>();
    }

    public class TaskItem
    {
        public int Id { get; set; }
        
        public int UserId { get; set; }
        [JsonIgnore]
        public User? User { get; set; }

        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public Sector Sector { get; set; }
        public IntervalType IntervalType { get; set; }
        public int? IntervalDays { get; set; }

        private DueDateType? _dueDate;
        public DueDateType DueDate
        {
            get => _dueDate ?? DueDateType.Null;
            set => _dueDate = value;
        }

        public DateTime? LastCompletedAt { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? SnoozedUntil { get; set; }
        public TaskState State { get; set; }
        public int DisplayOrder { get; set; }

        // Navigation property for completion logs
        public ICollection<TaskCompletionLog> CompletionLogs { get; set; } = new List<TaskCompletionLog>();
    }

    public class TaskCompletionLog
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public DateTime CompletedAt { get; set; }
        public string? Notes { get; set; }

        // Navigation property
        [JsonIgnore]
        public TaskItem? Task { get; set; }
    }
}
